<!DOCTYPE html>
<!-- saved from url=(0086)http://localhost/phpmyadmin/index.php?route=/database/structure&db=db_inventori_fitrah -->
<html lang="id" dir="ltr"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="referrer" content="no-referrer">
  <meta name="robots" content="noindex,nofollow,notranslate">
  <meta name="google" content="notranslate">
  
  <link rel="icon" href="http://localhost/phpmyadmin/favicon.ico" type="image/x-icon">
  <link rel="shortcut icon" href="http://localhost/phpmyadmin/favicon.ico" type="image/x-icon">
  <link rel="stylesheet" type="text/css" href="./db_inventori_fitrah_files/jquery-ui.css">
  <link rel="stylesheet" type="text/css" href="./db_inventori_fitrah_files/codemirror.css">
  <link rel="stylesheet" type="text/css" href="./db_inventori_fitrah_files/show-hint.css">
  <link rel="stylesheet" type="text/css" href="./db_inventori_fitrah_files/lint.css">
  <link rel="stylesheet" type="text/css" href="./db_inventori_fitrah_files/theme.css">
  <title>localhost / 127.0.0.1 / db_inventori_fitrah | phpMyAdmin 5.2.1</title>
    <script data-cfasync="false" type="text/javascript" src="./db_inventori_fitrah_files/jquery.min.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./db_inventori_fitrah_files/jquery-migrate.min.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./db_inventori_fitrah_files/sprintf.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./db_inventori_fitrah_files/ajax.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./db_inventori_fitrah_files/keyhandler.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./db_inventori_fitrah_files/jquery-ui.min.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./db_inventori_fitrah_files/name-conflict-fixes.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./db_inventori_fitrah_files/bootstrap.bundle.min.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./db_inventori_fitrah_files/js.cookie.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./db_inventori_fitrah_files/jquery.validate.min.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./db_inventori_fitrah_files/jquery-ui-timepicker-addon.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./db_inventori_fitrah_files/jquery.debounce-1.0.6.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./db_inventori_fitrah_files/menu_resizer.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./db_inventori_fitrah_files/cross_framing_protection.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./db_inventori_fitrah_files/messages.php"></script>
  <script data-cfasync="false" type="text/javascript" src="./db_inventori_fitrah_files/config.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./db_inventori_fitrah_files/doclinks.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./db_inventori_fitrah_files/functions.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./db_inventori_fitrah_files/navigation.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./db_inventori_fitrah_files/indexes.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./db_inventori_fitrah_files/common.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./db_inventori_fitrah_files/page_settings.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./db_inventori_fitrah_files/home.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./db_inventori_fitrah_files/codemirror.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./db_inventori_fitrah_files/sql.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./db_inventori_fitrah_files/runmode.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./db_inventori_fitrah_files/show-hint.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./db_inventori_fitrah_files/sql-hint.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./db_inventori_fitrah_files/lint.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./db_inventori_fitrah_files/sql-lint.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./db_inventori_fitrah_files/tracekit.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./db_inventori_fitrah_files/error_report.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./db_inventori_fitrah_files/drag_drop_import.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./db_inventori_fitrah_files/shortcuts_handler.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./db_inventori_fitrah_files/console.js.download"></script>

<script data-cfasync="false" type="text/javascript">
// <![CDATA[
CommonParams.setAll({common_query:"",opendb_url:"index.php?route=/database/structure",lang:"id",server:"1",table:"",db:"",token:"2e7558593b5a5173314b356f4a394569",text_dir:"ltr",LimitChars:"50",pftext:"",confirm:true,LoginCookieValidity:"1440",session_gc_maxlifetime:"1440",logged_in:true,is_https:false,rootPath:"/phpmyadmin/",arg_separator:"&",version:"5.2.1",auth_type:"config",user:"root"});
var firstDayOfCalendar = '0';
var themeImagePath = '.\/themes\/pmahomme\/img\/';
var mysqlDocTemplate = '.\/url.php\u003Furl\u003Dhttps\u00253A\u00252F\u00252Fdev.mysql.com\u00252Fdoc\u00252Frefman\u00252F8.0\u00252Fen\u00252F\u002525s.html';
var maxInputVars = 1000;

if ($.datepicker) {
  $.datepicker.regional[''].closeText = 'Selesai';
  $.datepicker.regional[''].prevText = 'Prev';
  $.datepicker.regional[''].nextText = 'Berikutnya';
  $.datepicker.regional[''].currentText = 'Hari\u0020ini';
  $.datepicker.regional[''].monthNames = [
    'Januari',
    'Februari',
    'Maret',
    'April',
    'Mei',
    'Juni',
    'Juli',
    'Agustus',
    'September',
    'Oktober',
    'November',
    'Desember',
  ];
  $.datepicker.regional[''].monthNamesShort = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'Mei',
    'Jun',
    'Jul',
    'Agu',
    'Sep',
    'Okt',
    'Nov',
    'Des',
  ];
  $.datepicker.regional[''].dayNames = [
    'Minggu',
    'Senin',
    'Selasa',
    'Rabu',
    'Kamis',
    'Jumat',
    'Sabtu',
  ];
  $.datepicker.regional[''].dayNamesShort = [
    'Min',
    'Sen',
    'Sel',
    'Rab',
    'Kam',
    'Jum',
    'Sab',
  ];
  $.datepicker.regional[''].dayNamesMin = [
    'Min',
    'Sn',
    'Sl',
    'Rb',
    'Km',
    'Jm',
    'Sb',
  ];
  $.datepicker.regional[''].weekHeader = 'Mingguan';
  $.datepicker.regional[''].showMonthAfterYear = false;
  $.datepicker.regional[''].yearSuffix = '';
  $.extend($.datepicker._defaults, $.datepicker.regional['']);
}

if ($.timepicker) {
  $.timepicker.regional[''].timeText = 'Waktu';
  $.timepicker.regional[''].hourText = 'Jam';
  $.timepicker.regional[''].minuteText = 'Menit';
  $.timepicker.regional[''].secondText = 'Detik';
  $.extend($.timepicker._defaults, $.timepicker.regional['']);
}

function extendingValidatorMessages () {
  $.extend($.validator.messages, {
    required: 'Wajib\u0020diisi',
    remote: 'Silakan\u0020perbaiki\u0020kolom\u0020ini',
    email: 'Silakan\u0020masukkan\u0020alamat\u0020email\u0020yang\u0020valid',
    url: 'Silakan\u0020masukkan\u0020URL\u0020yang\u0020valid',
    date: 'Silakan\u0020masukkan\u0020tanggal\u0020yang\u0020valid',
    dateISO: 'Silakan\u0020masukkan\u0020tanggal\u0020yang\u0020valid\u0020\u0028ISO\u0029',
    number: 'Silakan\u0020masukkan\u0020angka\u0020yang\u0020valid',
    creditcard: 'Silakan\u0020masukkan\u0020nomor\u0020kartu\u0020kredit\u0020yang\u0020valid',
    digits: 'Silakan\u0020masukkan\u0020angka\u0020saja',
    equalTo: 'Silakan\u0020masukkan\u0020lagi\u0020nilai\u0020yang\u0020sama',
    maxlength: $.validator.format('Silakan\u0020masukkan\u0020tidak\u0020lebih\u0020dari\u0020\u007B0\u007D\u0020karakter'),
    minlength: $.validator.format('Silakan\u0020masukkan\u0020setidaknya\u0020\u007B0\u007D\u0020karakter'),
    rangelength: $.validator.format('Silakan\u0020masukkan\u0020nilai\u0020panjang\u0020karakter\u0020antara\u0020\u007B0\u007D\u0020dan\u0020\u007B1\u007D'),
    range: $.validator.format('Silakan\u0020masukkan'),
    max: $.validator.format('Silakan\u0020masukkan\u0020nilai\u0020kurang\u0020dari\u0020atau\u0020sama\u0020dengan\u0020\u007B0\u007D'),
    min: $.validator.format('Silakan\u0020masukkan\u0020nilai\u0020lebih\u0020dari\u0020atau\u0020sama\u0020dengan\u0020\u007B0\u007D'),
    validationFunctionForDateTime: $.validator.format('Silakan\u0020masukkan\u0020tanggal\u0020dan\u0020jam\u0020yang\u0020valid'),
    validationFunctionForHex: $.validator.format('Silakan\u0020masukkan\u0020input\u0020HEX\u0020yang\u0020valid'),
    validationFunctionForMd5: $.validator.format('This\u0020column\u0020can\u0020not\u0020contain\u0020a\u002032\u0020chars\u0020value'),
    validationFunctionForAesDesEncrypt: $.validator.format('These\u0020functions\u0020are\u0020meant\u0020to\u0020return\u0020a\u0020binary\u0020result\u003B\u0020to\u0020avoid\u0020inconsistent\u0020results\u0020you\u0020should\u0020store\u0020it\u0020in\u0020a\u0020BINARY,\u0020VARBINARY,\u0020or\u0020BLOB\u0020column.')
  });
}

ConsoleEnterExecutes=false

AJAX.scriptHandler
  .add('vendor/jquery/jquery.min.js', 0)
  .add('vendor/jquery/jquery-migrate.min.js', 0)
  .add('vendor/sprintf.js', 1)
  .add('ajax.js', 0)
  .add('keyhandler.js', 1)
  .add('vendor/jquery/jquery-ui.min.js', 0)
  .add('name-conflict-fixes.js', 1)
  .add('vendor/bootstrap/bootstrap.bundle.min.js', 1)
  .add('vendor/js.cookie.js', 1)
  .add('vendor/jquery/jquery.validate.min.js', 0)
  .add('vendor/jquery/jquery-ui-timepicker-addon.js', 0)
  .add('vendor/jquery/jquery.debounce-1.0.6.js', 0)
  .add('menu_resizer.js', 1)
  .add('cross_framing_protection.js', 0)
  .add('messages.php', 0)
  .add('config.js', 1)
  .add('doclinks.js', 1)
  .add('functions.js', 1)
  .add('navigation.js', 1)
  .add('indexes.js', 1)
  .add('common.js', 1)
  .add('page_settings.js', 1)
  .add('home.js', 1)
  .add('vendor/codemirror/lib/codemirror.js', 0)
  .add('vendor/codemirror/mode/sql/sql.js', 0)
  .add('vendor/codemirror/addon/runmode/runmode.js', 0)
  .add('vendor/codemirror/addon/hint/show-hint.js', 0)
  .add('vendor/codemirror/addon/hint/sql-hint.js', 0)
  .add('vendor/codemirror/addon/lint/lint.js', 0)
  .add('codemirror/addon/lint/sql-lint.js', 0)
  .add('vendor/tracekit.js', 1)
  .add('error_report.js', 1)
  .add('drag_drop_import.js', 1)
  .add('shortcuts_handler.js', 1)
  .add('console.js', 1)
;
$(function() {
        AJAX.fireOnload('vendor/sprintf.js');
        AJAX.fireOnload('keyhandler.js');
        AJAX.fireOnload('name-conflict-fixes.js');
      AJAX.fireOnload('vendor/bootstrap/bootstrap.bundle.min.js');
      AJAX.fireOnload('vendor/js.cookie.js');
            AJAX.fireOnload('menu_resizer.js');
          AJAX.fireOnload('config.js');
      AJAX.fireOnload('doclinks.js');
      AJAX.fireOnload('functions.js');
      AJAX.fireOnload('navigation.js');
      AJAX.fireOnload('indexes.js');
      AJAX.fireOnload('common.js');
      AJAX.fireOnload('page_settings.js');
      AJAX.fireOnload('home.js');
                    AJAX.fireOnload('vendor/tracekit.js');
      AJAX.fireOnload('error_report.js');
      AJAX.fireOnload('drag_drop_import.js');
      AJAX.fireOnload('shortcuts_handler.js');
      AJAX.fireOnload('console.js');
  });
// ]]>
</script>

  <noscript><style>html{display:block}</style></noscript>
<script type="text/javascript" src="./db_inventori_fitrah_files/databases.js.download"></script><script type="text/javascript" src="./db_inventori_fitrah_files/makegrid.js.download"></script><script type="text/javascript" src="./db_inventori_fitrah_files/jquery.uitablefilter.js.download"></script><script type="text/javascript" src="./db_inventori_fitrah_files/sql(1).js.download"></script><script type="text/javascript" src="./db_inventori_fitrah_files/structure.js.download"></script><script type="text/javascript" src="./db_inventori_fitrah_files/change.js.download"></script><script type="text/javascript" src="./db_inventori_fitrah_files/gis_data_editor.js.download"></script><script type="text/javascript" src="./db_inventori_fitrah_files/multi_column_sort.js.download"></script><script type="text/javascript" src="./db_inventori_fitrah_files/structure(1).js.download"></script></head>
<body style="margin-bottom: 21.4375px; margin-left: 240px; padding-top: 59.5625px; cursor: inherit;">
    <div id="pma_navigation" class="d-print-none" data-config-navigation-width="240" style="width: 240px;">
    <div id="pma_navigation_resizer" style="left: 240px; width: 3px;"></div>
    <div id="pma_navigation_collapser" title="Sembunyikan panel" style="left: 240px;">←</div>
    <div id="pma_navigation_content">
      <div id="pma_navigation_header">

                  <div id="pmalogo">
                          <a href="http://localhost/phpmyadmin/index.php">
                                      <img id="imgpmalogo" src="./db_inventori_fitrah_files/logo_left.png" alt="phpMyAdmin">
                                      </a>
                      </div>
        
        <div id="navipanellinks">
          <a href="http://localhost/phpmyadmin/index.php?route=/" title="Beranda"><img src="./db_inventori_fitrah_files/dot.gif" title="Beranda" alt="Beranda" class="icon ic_b_home"></a>

                      <a class="logout disableAjax" href="http://localhost/phpmyadmin/index.php?route=/logout" title="Sesi data kosong"><img src="./db_inventori_fitrah_files/dot.gif" title="Sesi data kosong" alt="Sesi data kosong" class="icon ic_s_loggoff"></a>
          
          <a href="http://localhost/phpmyadmin/doc/html/index.html" title="Dokumentasi phpMyAdmin" target="_blank" rel="noopener noreferrer"><img src="./db_inventori_fitrah_files/dot.gif" title="Dokumentasi phpMyAdmin" alt="Dokumentasi phpMyAdmin" class="icon ic_b_docs"></a>

          <a href="http://localhost/phpmyadmin/url.php?url=https%3A%2F%2Fmariadb.com%2Fkb%2Fen%2Fdocumentation%2F" title="MariaDB Documentation" target="_blank" rel="noopener noreferrer"><img src="./db_inventori_fitrah_files/dot.gif" title="MariaDB Documentation" alt="MariaDB Documentation" class="icon ic_b_sqlhelp"></a>

          <a id="pma_navigation_settings_icon" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#" title="Pengaturan panel navigasi"><img src="./db_inventori_fitrah_files/dot.gif" title="Pengaturan panel navigasi" alt="Pengaturan panel navigasi" class="icon ic_s_cog"></a>

          <a id="pma_navigation_reload" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#" title="Muat ulang panel navigasi"><img src="./db_inventori_fitrah_files/dot.gif" title="Muat ulang panel navigasi" alt="Muat ulang panel navigasi" class="icon ic_s_reload"></a>
        </div>

        
        <img src="./db_inventori_fitrah_files/dot.gif" title="Memproses…" alt="Memproses…" style="visibility: hidden; display:none" class="icon ic_ajax_clock_small throbber">
      </div>
      <div id="pma_navigation_tree" class="list_container synced highlight autoexpand" style="height: 583.312px;">
  <div class="pma_quick_warp">
    <div class="drop_list"><button title="Tabel terakhir" class="drop_button btn">Terbaru</button><ul id="pma_recent_list"><li class="warp_link">
  <a href="http://localhost/phpmyadmin/index.php?route=/table/recent-favorite&amp;db=db_inventori_fitrah&amp;table=barang">
    `db_inventori_fitrah`.`barang`
  </a>
</li>
<li class="warp_link">
  <a href="http://localhost/phpmyadmin/index.php?route=/table/recent-favorite&amp;db=penjualan&amp;table=barang">
    `penjualan`.`barang`
  </a>
</li>
<li class="warp_link">
  <a href="http://localhost/phpmyadmin/index.php?route=/table/recent-favorite&amp;db=&amp;table=barang">
    ``.`barang`
  </a>
</li>
<li class="warp_link">
  <a href="http://localhost/phpmyadmin/index.php?route=/table/recent-favorite&amp;db=db_inventori_lab_fitrah&amp;table=barang">
    `db_inventori_lab_fitrah`.`barang`
  </a>
</li>
<li class="warp_link">
  <a href="http://localhost/phpmyadmin/index.php?route=/table/recent-favorite&amp;db=db_inventori_lab_fitrah&amp;table=kategori">
    `db_inventori_lab_fitrah`.`kategori`
  </a>
</li>
<li class="warp_link">
  <a href="http://localhost/phpmyadmin/index.php?route=/table/recent-favorite&amp;db=tokorenxia&amp;table=barang">
    `tokorenxia`.`barang`
  </a>
</li>
<li class="warp_link">
  <a href="http://localhost/phpmyadmin/index.php?route=/table/recent-favorite&amp;db=tokorenxia&amp;table=pelanggan">
    `tokorenxia`.`pelanggan`
  </a>
</li>
<li class="warp_link">
  <a href="http://localhost/phpmyadmin/index.php?route=/table/recent-favorite&amp;db=kasir_koperasi&amp;table=transaksi">
    `kasir_koperasi`.`transaksi`
  </a>
</li>
<li class="warp_link">
  <a href="http://localhost/phpmyadmin/index.php?route=/table/recent-favorite&amp;db=kasir_koperasi&amp;table=produk">
    `kasir_koperasi`.`produk`
  </a>
</li>
<li class="warp_link">
  <a href="http://localhost/phpmyadmin/index.php?route=/table/recent-favorite&amp;db=kasir_koperasi&amp;table=piutang">
    `kasir_koperasi`.`piutang`
  </a>
</li>
</ul></div>    <div class="drop_list"><button title="Tabel favorit" class="drop_button btn">Favorit</button><ul id="pma_favorite_list"><li class="warp_link">
            Tidak ada tabel favorit terbaru.    </li>
</ul></div>    <div class="clearfloat"></div>
</div>


<div class="clearfloat"></div>

<ul>
  
  <!-- CONTROLS START -->
<li id="navigation_controls_outer">
    <div id="navigation_controls">
        <a href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#" id="pma_navigation_collapse" title="Tutup semua"><img src="./db_inventori_fitrah_files/dot.gif" title="Tutup semua" alt="Tutup semua" class="icon ic_s_collapseall"></a>
        <a href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#" id="pma_navigation_sync" title="Unlink dari panel utama"><img src="./db_inventori_fitrah_files/dot.gif" title="Unlink dari panel utama" alt="Unlink dari panel utama" class="icon ic_s_link"></a>
    </div>
</li>
<!-- CONTROLS ENDS -->

</ul>



<div id="pma_navigation_tree_content" style="height: 528.375px;">
  <ul>
      <li class="first new_database italics">
    <div class="block">
      <i class="first"></i>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/server/databases"><img src="./db_inventori_fitrah_files/dot.gif" title="Baru" alt="Baru" class="icon ic_b_newdb"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/server/databases" title="Baru">Baru</a>
          
    

    
    <div class="clearfloat"></div>



  </li>
  <li class="navGroup">
    <div class="block">
      <i></i>
              <b></b>
        <a class="expander loaded container" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#">
          <span class="hide paths_nav" data-apath="cm9vdA==" data-vpath="cm9vdA==.ZGI=" data-pos="0"></span>
                    <img src="./db_inventori_fitrah_files/dot.gif" title="" alt="" class="icon ic_b_minus">
        </a>
          </div>
          <div class="fst-italic">
    
          <div class="block second">
        <u><img src="./db_inventori_fitrah_files/dot.gif" title="Groups" alt="Groups" class="icon ic_b_group"></u>
      </div>
      &nbsp;db
    
    

          </div>
    
    <div class="clearfloat"></div>

  <div class="list_container">
    <ul>
  <li class="database database">
    <div class="block">
      <i></i>
              <b></b>
        <a class="expander" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#">
          <span class="hide paths_nav" data-apath="cm9vdA==.ZGJfZml0cmFo" data-vpath="cm9vdA==.ZGI=.Zml0cmFo" data-pos="0"></span>
                    <img src="./db_inventori_fitrah_files/dot.gif" title="Bentangkan/Tutup" alt="Bentangkan/Tutup" class="icon ic_b_plus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=db_fitrah"><img src="./db_inventori_fitrah_files/dot.gif" title="Operasi database" alt="Operasi database" class="icon ic_s_db"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_fitrah" title="Struktur">db_fitrah</a>
          
    

    
    <div class="clearfloat"></div>



  </li>
  <li class="navGroup navGroup">
    <div class="block">
      <i></i>
              <b></b>
        <a class="expander loaded container" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#">
          <span class="hide paths_nav" data-apath="cm9vdA==" data-vpath="cm9vdA==.ZGI=.aW52ZW50b3Jp" data-pos="0"></span>
                    <img src="./db_inventori_fitrah_files/dot.gif" title="" alt="" class="icon ic_b_minus">
        </a>
          </div>
          <div class="fst-italic">
    
          <div class="block second">
        <u><img src="./db_inventori_fitrah_files/dot.gif" title="Groups" alt="Groups" class="icon ic_b_group"></u>
      </div>
      &nbsp;inventori
    
    

          </div>
    
    <div class="clearfloat"></div>

  <div class="list_container">
    <ul>
  <li class="database database selected">
    <div class="block">
      <i></i>
              <b></b>
        <a class="expander loaded" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#">
          <span class="hide paths_nav" data-apath="cm9vdA==.ZGJfaW52ZW50b3JpX2ZpdHJhaA==" data-vpath="cm9vdA==.ZGI=.aW52ZW50b3Jp.Zml0cmFo" data-pos="0"></span>
                    <img src="./db_inventori_fitrah_files/dot.gif" title="" alt="" class="icon ic_b_minus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=db_inventori_fitrah"><img src="./db_inventori_fitrah_files/dot.gif" title="Operasi database" alt="Operasi database" class="icon ic_s_db"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah" title="Struktur">db_inventori_fitrah</a>
          
    

    
    <div class="clearfloat"></div>

  <div class="list_container">
    <ul>
  <span class="hide pos2_nav" data-name="tables" data-value="0"></span>

  <li class="new_table italics new_table italics">
    <div class="block">
      <i></i>
              <span class="hide pos2_nav" data-name="tables" data-value="0"></span>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/table/create&amp;db=db_inventori_fitrah"><img src="./db_inventori_fitrah_files/dot.gif" title="Baru" alt="Baru" class="icon ic_b_table_add"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/table/create&amp;db=db_inventori_fitrah" title="Baru">Baru</a>
          
    

    
    <div class="clearfloat"></div>



  </li>
  <li class="nav_node_table last nav_node_table">
    <div class="block">
      <i></i>
              
        <a class="expander" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#">
          <span class="hide paths_nav" data-apath="cm9vdA==.ZGJfaW52ZW50b3JpX2ZpdHJhaA==.dGFibGVz.YmFyYW5n" data-vpath="cm9vdA==.ZGI=.aW52ZW50b3Jp.Zml0cmFo.VGFiZWw=.YmFyYW5n" data-pos="0"></span>
                      <span class="hide pos2_nav" data-name="tables" data-value="0"></span>
                    <img src="./db_inventori_fitrah_files/dot.gif" title="Bentangkan/Tutup" alt="Bentangkan/Tutup" class="icon ic_b_plus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/table/structure&amp;db=db_inventori_fitrah&amp;table=barang"><img src="./db_inventori_fitrah_files/dot.gif" title="Struktur" alt="Struktur" class="icon ic_b_props"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/sql&amp;pos=0&amp;db=db_inventori_fitrah&amp;table=barang" title="Jelajahi">barang</a>
          
    <span class="navItemControls"><a href="http://localhost/phpmyadmin/index.php?route=/navigation" data-post="hideNavItem=1&amp;itemType=table&amp;itemName=barang&amp;dbName=db_inventori_fitrah" class="hideNavItem ajax"><img src="./db_inventori_fitrah_files/dot.gif" title="Sembunyikan" alt="Sembunyikan" class="icon ic_hide"></a></span>

    
    <div class="clearfloat"></div>



  </li>



    </ul>
  </div>

  </li>
  <li class="database last database">
    <div class="block">
      <i></i>
              
        <a class="expander" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#">
          <span class="hide paths_nav" data-apath="cm9vdA==.ZGJfaW52ZW50b3JpX2xhYl9maXRyYWg=" data-vpath="cm9vdA==.ZGI=.aW52ZW50b3Jp.bGFiX2ZpdHJhaA==" data-pos="0"></span>
                    <img src="./db_inventori_fitrah_files/dot.gif" title="Bentangkan/Tutup" alt="Bentangkan/Tutup" class="icon ic_b_plus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=db_inventori_lab_fitrah"><img src="./db_inventori_fitrah_files/dot.gif" title="Operasi database" alt="Operasi database" class="icon ic_s_db"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_lab_fitrah" title="Struktur">db_inventori_lab_fitrah</a>
          
    

    
    <div class="clearfloat"></div>



  </li>

    </ul>
  </div>

  </li>
  <li class="database database">
    <div class="block">
      <i></i>
              <b></b>
        <a class="expander" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#">
          <span class="hide paths_nav" data-apath="cm9vdA==.ZGJfa29wZXJhc2k=" data-vpath="cm9vdA==.ZGI=.a29wZXJhc2k=" data-pos="0"></span>
                    <img src="./db_inventori_fitrah_files/dot.gif" title="Bentangkan/Tutup" alt="Bentangkan/Tutup" class="icon ic_b_plus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=db_koperasi"><img src="./db_inventori_fitrah_files/dot.gif" title="Operasi database" alt="Operasi database" class="icon ic_s_db"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_koperasi" title="Struktur">db_koperasi</a>
          
    

    
    <div class="clearfloat"></div>



  </li>
  <li class="database last database">
    <div class="block">
      <i></i>
              
        <a class="expander" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#">
          <span class="hide paths_nav" data-apath="cm9vdA==.ZGJfcHJha3Rpa3Vta2JkX2ZpdHJhaA==" data-vpath="cm9vdA==.ZGI=.cHJha3Rpa3Vta2JkX2ZpdHJhaA==" data-pos="0"></span>
                    <img src="./db_inventori_fitrah_files/dot.gif" title="Bentangkan/Tutup" alt="Bentangkan/Tutup" class="icon ic_b_plus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=db_praktikumkbd_fitrah"><img src="./db_inventori_fitrah_files/dot.gif" title="Operasi database" alt="Operasi database" class="icon ic_s_db"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_praktikumkbd_fitrah" title="Struktur">db_praktikumkbd_fitrah</a>
          
    

    
    <div class="clearfloat"></div>



  </li>

    </ul>
  </div>

  </li>
  <li class="navGroup">
    <div class="block">
      <i></i>
              <b></b>
        <a class="expander loaded container" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#">
          <span class="hide paths_nav" data-apath="cm9vdA==" data-vpath="cm9vdA==.Zml0cmFo" data-pos="0"></span>
                    <img src="./db_inventori_fitrah_files/dot.gif" title="Bentangkan/Tutup" alt="Bentangkan/Tutup" class="icon ic_b_plus">
        </a>
          </div>
          <div class="fst-italic">
    
          <div class="block second">
        <u><img src="./db_inventori_fitrah_files/dot.gif" title="Groups" alt="Groups" class="icon ic_b_group"></u>
      </div>
      &nbsp;fitrah
    
    

          </div>
    
    <div class="clearfloat"></div>

  <div class="list_container" style="display: none;">
    <ul>
  <li class="database database">
    <div class="block">
      <i></i>
              <b></b>
        <a class="expander" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#">
          <span class="hide paths_nav" data-apath="cm9vdA==.Zml0cmFo" data-vpath="cm9vdA==.Zml0cmFo." data-pos="0"></span>
                    <img src="./db_inventori_fitrah_files/dot.gif" title="Bentangkan/Tutup" alt="Bentangkan/Tutup" class="icon ic_b_plus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=fitrah"><img src="./db_inventori_fitrah_files/dot.gif" title="Operasi database" alt="Operasi database" class="icon ic_s_db"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=fitrah" title="Struktur">fitrah</a>
          
    

    
    <div class="clearfloat"></div>



  </li>
  <li class="database last database">
    <div class="block">
      <i></i>
              
        <a class="expander" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#">
          <span class="hide paths_nav" data-apath="cm9vdA==.Zml0cmFoX2Ri" data-vpath="cm9vdA==.Zml0cmFo.ZGI=" data-pos="0"></span>
                    <img src="./db_inventori_fitrah_files/dot.gif" title="Bentangkan/Tutup" alt="Bentangkan/Tutup" class="icon ic_b_plus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=fitrah_db"><img src="./db_inventori_fitrah_files/dot.gif" title="Operasi database" alt="Operasi database" class="icon ic_s_db"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=fitrah_db" title="Struktur">fitrah_db</a>
          
    

    
    <div class="clearfloat"></div>



  </li>

    </ul>
  </div>

  </li>
  <li class="database">
    <div class="block">
      <i></i>
              <b></b>
        <a class="expander" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#">
          <span class="hide paths_nav" data-apath="cm9vdA==.aW5mb3JtYXRpb25fc2NoZW1h" data-vpath="cm9vdA==.aW5mb3JtYXRpb25fc2NoZW1h" data-pos="0"></span>
                    <img src="./db_inventori_fitrah_files/dot.gif" title="Bentangkan/Tutup" alt="Bentangkan/Tutup" class="icon ic_b_plus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=information_schema"><img src="./db_inventori_fitrah_files/dot.gif" title="Operasi database" alt="Operasi database" class="icon ic_s_db"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=information_schema" title="Struktur">information_schema</a>
          
    

    
    <div class="clearfloat"></div>



  </li>
  <li class="database">
    <div class="block">
      <i></i>
              <b></b>
        <a class="expander" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#">
          <span class="hide paths_nav" data-apath="cm9vdA==.a2FzaXJfa29wZXJhc2k=" data-vpath="cm9vdA==.a2FzaXJfa29wZXJhc2k=" data-pos="0"></span>
                    <img src="./db_inventori_fitrah_files/dot.gif" title="Bentangkan/Tutup" alt="Bentangkan/Tutup" class="icon ic_b_plus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=kasir_koperasi"><img src="./db_inventori_fitrah_files/dot.gif" title="Operasi database" alt="Operasi database" class="icon ic_s_db"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=kasir_koperasi" title="Struktur">kasir_koperasi</a>
          
    

    
    <div class="clearfloat"></div>



  </li>
  <li class="database">
    <div class="block">
      <i></i>
              <b></b>
        <a class="expander" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#">
          <span class="hide paths_nav" data-apath="cm9vdA==.a29wZXJhc2lfa2FtcHVz" data-vpath="cm9vdA==.a29wZXJhc2lfa2FtcHVz" data-pos="0"></span>
                    <img src="./db_inventori_fitrah_files/dot.gif" title="Bentangkan/Tutup" alt="Bentangkan/Tutup" class="icon ic_b_plus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=koperasi_kampus"><img src="./db_inventori_fitrah_files/dot.gif" title="Operasi database" alt="Operasi database" class="icon ic_s_db"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=koperasi_kampus" title="Struktur">koperasi_kampus</a>
          
    

    
    <div class="clearfloat"></div>



  </li>
  <li class="database">
    <div class="block">
      <i></i>
              <b></b>
        <a class="expander" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#">
          <span class="hide paths_nav" data-apath="cm9vdA==.bXlzcWw=" data-vpath="cm9vdA==.bXlzcWw=" data-pos="0"></span>
                    <img src="./db_inventori_fitrah_files/dot.gif" title="Bentangkan/Tutup" alt="Bentangkan/Tutup" class="icon ic_b_plus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=mysql"><img src="./db_inventori_fitrah_files/dot.gif" title="Operasi database" alt="Operasi database" class="icon ic_s_db"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=mysql" title="Struktur">mysql</a>
          
    

    
    <div class="clearfloat"></div>



  </li>
  <li class="database">
    <div class="block">
      <i></i>
              <b></b>
        <a class="expander" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#">
          <span class="hide paths_nav" data-apath="cm9vdA==.cGVuanVhbGFu" data-vpath="cm9vdA==.cGVuanVhbGFu" data-pos="0"></span>
                    <img src="./db_inventori_fitrah_files/dot.gif" title="Bentangkan/Tutup" alt="Bentangkan/Tutup" class="icon ic_b_plus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=penjualan"><img src="./db_inventori_fitrah_files/dot.gif" title="Operasi database" alt="Operasi database" class="icon ic_s_db"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=penjualan" title="Struktur">penjualan</a>
          
    

    
    <div class="clearfloat"></div>



  </li>
  <li class="database">
    <div class="block">
      <i></i>
              <b></b>
        <a class="expander" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#">
          <span class="hide paths_nav" data-apath="cm9vdA==.cGVyZm9ybWFuY2Vfc2NoZW1h" data-vpath="cm9vdA==.cGVyZm9ybWFuY2Vfc2NoZW1h" data-pos="0"></span>
                    <img src="./db_inventori_fitrah_files/dot.gif" title="Bentangkan/Tutup" alt="Bentangkan/Tutup" class="icon ic_b_plus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=performance_schema"><img src="./db_inventori_fitrah_files/dot.gif" title="Operasi database" alt="Operasi database" class="icon ic_s_db"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=performance_schema" title="Struktur">performance_schema</a>
          
    

    
    <div class="clearfloat"></div>



  </li>
  <li class="database">
    <div class="block">
      <i></i>
              <b></b>
        <a class="expander" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#">
          <span class="hide paths_nav" data-apath="cm9vdA==.cGhwbXlhZG1pbg==" data-vpath="cm9vdA==.cGhwbXlhZG1pbg==" data-pos="0"></span>
                    <img src="./db_inventori_fitrah_files/dot.gif" title="Bentangkan/Tutup" alt="Bentangkan/Tutup" class="icon ic_b_plus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=phpmyadmin"><img src="./db_inventori_fitrah_files/dot.gif" title="Operasi database" alt="Operasi database" class="icon ic_s_db"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=phpmyadmin" title="Struktur">phpmyadmin</a>
          
    

    
    <div class="clearfloat"></div>



  </li>
  <li class="database">
    <div class="block">
      <i></i>
              <b></b>
        <a class="expander" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#">
          <span class="hide paths_nav" data-apath="cm9vdA==.cHJha3Rpa3VtIGRtbA==" data-vpath="cm9vdA==.cHJha3Rpa3VtIGRtbA==" data-pos="0"></span>
                    <img src="./db_inventori_fitrah_files/dot.gif" title="Bentangkan/Tutup" alt="Bentangkan/Tutup" class="icon ic_b_plus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=praktikum+dml"><img src="./db_inventori_fitrah_files/dot.gif" title="Operasi database" alt="Operasi database" class="icon ic_s_db"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=praktikum+dml" title="Struktur">praktikum dml</a>
          
    

    
    <div class="clearfloat"></div>



  </li>
  <li class="database">
    <div class="block">
      <i></i>
              <b></b>
        <a class="expander" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#">
          <span class="hide paths_nav" data-apath="cm9vdA==.dGVzdA==" data-vpath="cm9vdA==.dGVzdA==" data-pos="0"></span>
                    <img src="./db_inventori_fitrah_files/dot.gif" title="Bentangkan/Tutup" alt="Bentangkan/Tutup" class="icon ic_b_plus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=test"><img src="./db_inventori_fitrah_files/dot.gif" title="Operasi database" alt="Operasi database" class="icon ic_s_db"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=test" title="Struktur">test</a>
          
    

    
    <div class="clearfloat"></div>



  </li>
  <li class="last database">
    <div class="block">
      <i></i>
              
        <a class="expander" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#">
          <span class="hide paths_nav" data-apath="cm9vdA==.dG9rb3JlbnhpYQ==" data-vpath="cm9vdA==.dG9rb3JlbnhpYQ==" data-pos="0"></span>
                    <img src="./db_inventori_fitrah_files/dot.gif" title="Bentangkan/Tutup" alt="Bentangkan/Tutup" class="icon ic_b_plus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=tokorenxia"><img src="./db_inventori_fitrah_files/dot.gif" title="Operasi database" alt="Operasi database" class="icon ic_s_db"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=tokorenxia" title="Struktur">tokorenxia</a>
          
    

    
    <div class="clearfloat"></div>



  </li>

  </ul>
</div>


</div>

      <div id="pma_navi_settings_container">
                  
              </div>
    </div>

          <div class="pma_drop_handler">
        Letakkan berkas disini      </div>
      <div class="pma_sql_import_status">
        <h2>
          SQL upload          ( <span class="pma_import_count">0</span> )
          <span class="close">x</span>
          <span class="minimize">-</span>
        </h2>
        <div></div>
      </div>
      </div>
  <div class="modal fade" id="unhideNavItemModal" tabindex="-1" aria-labelledby="unhideNavItemModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="unhideNavItemModalLabel">Tampilkan navigasi pohon item tersembunyi.</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
      </div>
      <div class="modal-body"></div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
      </div>
    </div>
  </div>
</div>

  <div class="modal fade" id="createViewModal" tabindex="-1" aria-labelledby="createViewModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" id="createViewModalDialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="createViewModalLabel">Buat tampilan</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
      </div>
      <div class="modal-body"></div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" id="createViewModalGoButton">Kirim</button>
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
      </div>
    </div>
  </div>
</div>


  
  

  
      
  
      <div id="floating_menubar" class="d-print-none" style="margin-left: 243px; left: 0px; position: fixed; top: 0px; width: 100%; z-index: 99;">
<nav id="server-breadcrumb" aria-label="breadcrumb">
  <ol class="breadcrumb breadcrumb-navbar">
    <li class="breadcrumb-item">
      <img src="./db_inventori_fitrah_files/dot.gif" title="" alt="" class="icon ic_s_host">
      <a href="http://localhost/phpmyadmin/index.php?route=/" data-raw-text="127.0.0.1" draggable="false">
        Server:        127.0.0.1
      </a>
    </li>

          <li class="breadcrumb-item">
        <img src="./db_inventori_fitrah_files/dot.gif" title="" alt="" class="icon ic_s_db">
        <a href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah" data-raw-text="db_inventori_fitrah" draggable="false">
          Database:          db_inventori_fitrah
        </a>
      </li>

            </ol>
</nav>
<div id="topmenucontainer" class="menucontainer">
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-label="Toggle navigation" aria-controls="navbarNav" aria-expanded="false">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav" style="width: auto; overflow: visible;">
      <ul id="topmenu" class="navbar-nav">
                  <li class="nav-item active">
            <a class="nav-link text-nowrap" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah">
              <img src="./db_inventori_fitrah_files/dot.gif" title="Struktur" alt="Struktur" class="icon ic_b_props">&nbsp;Struktur
                              <span class="visually-hidden">(sekarang)</span>
                          </a>
          </li>
                  <li class="nav-item">
            <a class="nav-link text-nowrap" href="http://localhost/phpmyadmin/index.php?route=/database/sql&amp;db=db_inventori_fitrah">
              <img src="./db_inventori_fitrah_files/dot.gif" title="SQL" alt="SQL" class="icon ic_b_sql">&nbsp;SQL
                          </a>
          </li>
                  <li class="nav-item">
            <a class="nav-link text-nowrap" href="http://localhost/phpmyadmin/index.php?route=/database/search&amp;db=db_inventori_fitrah">
              <img src="./db_inventori_fitrah_files/dot.gif" title="Cari" alt="Cari" class="icon ic_b_search">&nbsp;Cari
                          </a>
          </li>
                  <li class="nav-item">
            <a class="nav-link text-nowrap" href="http://localhost/phpmyadmin/index.php?route=/database/multi-table-query&amp;db=db_inventori_fitrah">
              <img src="./db_inventori_fitrah_files/dot.gif" title="Kueri" alt="Kueri" class="icon ic_s_db">&nbsp;Kueri
                          </a>
          </li>
                  <li class="nav-item">
            <a class="nav-link text-nowrap" href="http://localhost/phpmyadmin/index.php?route=/database/export&amp;db=db_inventori_fitrah">
              <img src="./db_inventori_fitrah_files/dot.gif" title="Ekspor" alt="Ekspor" class="icon ic_b_export">&nbsp;Ekspor
                          </a>
          </li>
                  <li class="nav-item">
            <a class="nav-link text-nowrap" href="http://localhost/phpmyadmin/index.php?route=/database/import&amp;db=db_inventori_fitrah">
              <img src="./db_inventori_fitrah_files/dot.gif" title="Impor" alt="Impor" class="icon ic_b_import">&nbsp;Impor
                          </a>
          </li>
                  <li class="nav-item">
            <a class="nav-link text-nowrap" href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=db_inventori_fitrah">
              <img src="./db_inventori_fitrah_files/dot.gif" title="Operasi" alt="Operasi" class="icon ic_b_tblops">&nbsp;Operasi
                          </a>
          </li>
                  <li class="nav-item">
            <a class="nav-link text-nowrap" href="http://localhost/phpmyadmin/index.php?route=/server/privileges&amp;db=db_inventori_fitrah&amp;checkprivsdb=db_inventori_fitrah&amp;viewing_mode=db">
              <img src="./db_inventori_fitrah_files/dot.gif" title="Hak Akses" alt="Hak Akses" class="icon ic_s_rights">&nbsp;Hak Akses
                          </a>
          </li>
                  <li class="nav-item">
            <a class="nav-link text-nowrap" href="http://localhost/phpmyadmin/index.php?route=/database/routines&amp;db=db_inventori_fitrah">
              <img src="./db_inventori_fitrah_files/dot.gif" title="Routine" alt="Routine" class="icon ic_b_routines">&nbsp;Routine
                          </a>
          </li>
                  <li class="nav-item">
            <a class="nav-link text-nowrap" href="http://localhost/phpmyadmin/index.php?route=/database/events&amp;db=db_inventori_fitrah">
              <img src="./db_inventori_fitrah_files/dot.gif" title="Event" alt="Event" class="icon ic_b_events">&nbsp;Event
                          </a>
          </li>
                  <li class="nav-item">
            <a class="nav-link text-nowrap" href="http://localhost/phpmyadmin/index.php?route=/database/triggers&amp;db=db_inventori_fitrah">
              <img src="./db_inventori_fitrah_files/dot.gif" title="Trigger" alt="Trigger" class="icon ic_b_triggers">&nbsp;Trigger
                          </a>
          </li>
                  <li class="nav-item">
            <a class="nav-link text-nowrap" href="http://localhost/phpmyadmin/index.php?route=/database/tracking&amp;db=db_inventori_fitrah">
              <img src="./db_inventori_fitrah_files/dot.gif" title="Pelacakan" alt="Pelacakan" class="icon ic_eye">&nbsp;Pelacakan
                          </a>
          </li>
                  
                  
              <li class="nav-item dropdown" style=""><a href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#" class="nav-link dropdown-toggle" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img alt="" title="" src="./db_inventori_fitrah_files/dot.gif" class="icon ic_b_more">Lainnya</a><ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown"><li class="dropdown-item">
            <a class="nav-link text-nowrap" href="http://localhost/phpmyadmin/index.php?route=/database/designer&amp;db=db_inventori_fitrah">
              <img src="./db_inventori_fitrah_files/dot.gif" title="Desainer" alt="Desainer" class="icon ic_b_relations">&nbsp;Desainer
                          </a>
          </li><li class="dropdown-item">
            <a class="nav-link text-nowrap" href="http://localhost/phpmyadmin/index.php?route=/database/central-columns&amp;db=db_inventori_fitrah">
              <img src="./db_inventori_fitrah_files/dot.gif" title="Tengah kolom" alt="Tengah kolom" class="icon ic_centralColumns">&nbsp;Tengah kolom
                          </a>
          </li></ul></li></ul>
    </div>
  </nav>
</div>
</div>



    <span id="page_nav_icons" class="d-print-none">
      <span id="lock_page_icon"></span>
      <span id="page_settings_icon" style="display: inline;">
        <img src="./db_inventori_fitrah_files/dot.gif" title="Pengaturan Terkait dengan Halaman" alt="Pengaturan Terkait dengan Halaman" class="icon ic_s_cog">
      </span>
      <a id="goto_pagetop" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#"><img src="./db_inventori_fitrah_files/dot.gif" title="Klik pada bar untuk menggulir ke atas halaman" alt="Klik pada bar untuk menggulir ke atas halaman" class="icon ic_s_top"></a>
    </span>
  
  <div id="pma_console_container" class="d-print-none">
    <div id="pma_console" style="margin-left: 243px;">
                <div class="toolbar collapsed">
                    <div class="switch_button console_switch">
            <img src="./db_inventori_fitrah_files/dot.gif" title="Konsol Kueri SQL" alt="Konsol Kueri SQL" class="icon ic_console">
            <span>Konsol</span>
        </div>
                            <div class="button clear">
            
            <span>Bersihkan</span>
        </div>
                            <div class="button history">
            
            <span>Riwayat</span>
        </div>
                            <div class="button options">
            
            <span>Opsi</span>
        </div>
                            <div class="button bookmarks">
            
            <span>Bookmark</span>
        </div>
                            <div class="button debug hide">
            
            <span>Men-Debug SQL</span>
        </div>
            </div>
                <div class="content" style="height: 98.248px; margin-bottom: -98.2344px; display: none;">
            <div class="console_message_container">
                <div class="message welcome binded">
                    <span id="instructions-0">
                        Tekan Ctrl+Enter untuk menjalankan kueri                    </span>
                    <span class="hide" id="instructions-1">
                        Press Enter to execute query                    </span>
                </div>
                            <div class="message collapsed binded successed" msgid="602467784195"><div class="action_content">
                    <span class="action collapse">
            Tampilkan
                    </span>
                            <span class="action expand">
            Buka
                    </span>
                            <span class="action requery">
            Kueri ulang
                    </span>
                            <span class="action edit">
            Ubah
                    </span>
                            <span class="action explain">
            Jelaskan
                    </span>
                            <span class="action profiling">
            Profil
                    </span>
                            <span class="action bookmark">
            Bookmarks
                    </span>
                            <span class="text failed">
            Kueri gagal
                    </span>
                            <span class="text targetdb">
            Basis data
                            : <span></span>
                    </span>
                            <span class="text query_time" title="Fri Nov 06 2026 20:10:59 GMT+0700 (Western Indonesia Time)">
            Waktu eksekusi kueri
                            : <span>20:10:59</span>
                    </span>
            </div><div class="query highlighted"><span class="cm-keyword">CREATE</span> <span class="cm-keyword">TABLE</span> barang <span class="cm-bracket">(</span>
    kode_barang <span class="cm-type">VARCHAR</span><span class="cm-bracket">(</span><span class="cm-number">10</span><span class="cm-bracket">)</span> PRIMARY KEY<span class="cm-punctuation">,</span>
    nama_barang <span class="cm-type">VARCHAR</span><span class="cm-bracket">(</span><span class="cm-number">50</span><span class="cm-bracket">)</span> <span class="cm-keyword">NOT</span> <span class="cm-atom">NULL</span><span class="cm-punctuation">,</span>
    kategori <span class="cm-type">VARCHAR</span><span class="cm-bracket">(</span><span class="cm-number">20</span><span class="cm-bracket">)</span> <span class="cm-keyword">NOT</span> <span class="cm-atom">NULL</span><span class="cm-punctuation">,</span>
    stok <span class="cm-type">INT</span> <span class="cm-keyword">NOT</span> <span class="cm-atom">NULL</span>
<span class="cm-bracket">)</span><span class="cm-punctuation">;</span></div></div><div class="message collapsed binded select successed" msgid="499889563177" targetdb="db_inventori_fitrah" targettable="barang"><div class="action_content">
                    <span class="action collapse">
            Tampilkan
                    </span>
                            <span class="action expand">
            Buka
                    </span>
                            <span class="action requery">
            Kueri ulang
                    </span>
                            <span class="action edit">
            Ubah
                    </span>
                            <span class="action explain">
            Jelaskan
                    </span>
                            <span class="action profiling">
            Profil
                    </span>
                            <span class="action bookmark">
            Bookmarks
                    </span>
                            <span class="text failed">
            Kueri gagal
                    </span>
                            <span class="text targetdb">
            Basis data
                            : <span>db_inventori_fitrah</span>
                    </span>
                            <span class="text query_time" title="Fri Nov 06 2026 20:26:03 GMT+0700 (Western Indonesia Time)">
            Waktu eksekusi kueri
                            : <span>20:26:3</span>
                    </span>
            </div><div class="query highlighted"><span class="cm-keyword">SELECT</span> <span class="cm-operator">*</span> <span class="cm-keyword">FROM</span> `barang`</div></div><div class="message collapsed binded successed" msgid="939236110483"><div class="action_content">
                    <span class="action collapse">
            Tampilkan
                    </span>
                            <span class="action expand">
            Buka
                    </span>
                            <span class="action requery">
            Kueri ulang
                    </span>
                            <span class="action edit">
            Ubah
                    </span>
                            <span class="action explain">
            Jelaskan
                    </span>
                            <span class="action profiling">
            Profil
                    </span>
                            <span class="action bookmark">
            Bookmarks
                    </span>
                            <span class="text failed">
            Kueri gagal
                    </span>
                            <span class="text targetdb">
            Basis data
                            : <span></span>
                    </span>
                            <span class="text query_time" title="Fri Nov 06 2026 20:45:28 GMT+0700 (Western Indonesia Time)">
            Waktu eksekusi kueri
                            : <span>20:45:28</span>
                    </span>
            </div><div class="query highlighted"><span class="cm-keyword">INSERT</span> <span class="cm-keyword">INTO</span> barang
<span class="cm-bracket">(</span>kode_barang<span class="cm-punctuation">,</span> nama_barang<span class="cm-punctuation">,</span> kategori<span class="cm-punctuation">,</span> stok<span class="cm-bracket">)</span>
<span class="cm-keyword">VALUES</span>
<span class="cm-bracket">(</span><span class="cm-string">'BRG01'</span><span class="cm-punctuation">,</span> <span class="cm-string">'Mouse USB'</span><span class="cm-punctuation">,</span> <span class="cm-string">'Komputer'</span><span class="cm-punctuation">,</span> <span class="cm-number">15</span><span class="cm-bracket">)</span><span class="cm-punctuation">,</span>
<span class="cm-bracket">(</span><span class="cm-string">'BRG02'</span><span class="cm-punctuation">,</span> <span class="cm-string">'Kabel UTP Cat6 (roll)'</span><span class="cm-punctuation">,</span> <span class="cm-string">'Jaringan'</span><span class="cm-punctuation">,</span> <span class="cm-number">3</span><span class="cm-bracket">)</span><span class="cm-punctuation">,</span>
<span class="cm-bracket">(</span><span class="cm-string">'BRG03'</span><span class="cm-punctuation">,</span> <span class="cm-string">'Multimeter Digital'</span><span class="cm-punctuation">,</span> <span class="cm-string">'Alat Ukur'</span><span class="cm-punctuation">,</span> <span class="cm-number">5</span><span class="cm-bracket">)</span><span class="cm-punctuation">;</span></div></div><div class="message collapsed binded select successed" msgid="153919798607" targetdb="db_inventori_fitrah" targettable="barang"><div class="action_content">
                    <span class="action collapse">
            Tampilkan
                    </span>
                            <span class="action expand">
            Buka
                    </span>
                            <span class="action requery">
            Kueri ulang
                    </span>
                            <span class="action edit">
            Ubah
                    </span>
                            <span class="action explain">
            Jelaskan
                    </span>
                            <span class="action profiling">
            Profil
                    </span>
                            <span class="action bookmark">
            Bookmarks
                    </span>
                            <span class="text failed">
            Kueri gagal
                    </span>
                            <span class="text targetdb">
            Basis data
                            : <span>db_inventori_fitrah</span>
                    </span>
                            <span class="text query_time" title="Fri Nov 06 2026 20:45:31 GMT+0700 (Western Indonesia Time)">
            Waktu eksekusi kueri
                            : <span>20:45:31</span>
                    </span>
            </div><div class="query highlighted"><span class="cm-keyword">SELECT</span> <span class="cm-operator">*</span> <span class="cm-keyword">FROM</span> `barang`</div></div><div class="message collapsed binded successed" msgid="310668225710"><div class="action_content">
                    <span class="action collapse">
            Tampilkan
                    </span>
                            <span class="action expand">
            Buka
                    </span>
                            <span class="action requery">
            Kueri ulang
                    </span>
                            <span class="action edit">
            Ubah
                    </span>
                            <span class="action explain">
            Jelaskan
                    </span>
                            <span class="action profiling">
            Profil
                    </span>
                            <span class="action bookmark">
            Bookmarks
                    </span>
                            <span class="text failed">
            Kueri gagal
                    </span>
                            <span class="text targetdb">
            Basis data
                            : <span></span>
                    </span>
                            <span class="text query_time" title="Fri Nov 06 2026 20:49:19 GMT+0700 (Western Indonesia Time)">
            Waktu eksekusi kueri
                            : <span>20:49:19</span>
                    </span>
            </div><div class="query highlighted">SHOW DATABASES<span class="cm-punctuation">;</span></div></div><div class="message collapsed binded select successed" msgid="283046466964"><div class="action_content">
                    <span class="action collapse">
            Tampilkan
                    </span>
                            <span class="action expand">
            Buka
                    </span>
                            <span class="action requery">
            Kueri ulang
                    </span>
                            <span class="action edit">
            Ubah
                    </span>
                            <span class="action explain">
            Jelaskan
                    </span>
                            <span class="action profiling">
            Profil
                    </span>
                            <span class="action bookmark">
            Bookmarks
                    </span>
                            <span class="text failed">
            Kueri gagal
                    </span>
                            <span class="text targetdb">
            Basis data
                            : <span></span>
                    </span>
                            <span class="text query_time" title="Fri Nov 06 2026 20:50:59 GMT+0700 (Western Indonesia Time)">
            Waktu eksekusi kueri
                            : <span>20:50:59</span>
                    </span>
            </div><div class="query highlighted"><span class="cm-keyword">SELECT</span>
    DATABASE<span class="cm-bracket">(</span><span class="cm-bracket">)</span> <span class="cm-keyword">AS</span> database_aktif<span class="cm-punctuation">,</span>
    @@hostname <span class="cm-keyword">AS</span> nama_server<span class="cm-punctuation">,</span>
    @@port <span class="cm-keyword">AS</span> port_mysql<span class="cm-punctuation">,</span>
    @@datadir <span class="cm-keyword">AS</span> lokasi_database<span class="cm-punctuation">;</span></div></div><div class="message collapsed binded select successed" msgid="584426061641"><div class="action_content">
                    <span class="action collapse">
            Tampilkan
                    </span>
                            <span class="action expand">
            Buka
                    </span>
                            <span class="action requery">
            Kueri ulang
                    </span>
                            <span class="action edit">
            Ubah
                    </span>
                            <span class="action explain">
            Jelaskan
                    </span>
                            <span class="action profiling">
            Profil
                    </span>
                            <span class="action bookmark">
            Bookmarks
                    </span>
                            <span class="text failed">
            Kueri gagal
                    </span>
                            <span class="text targetdb">
            Basis data
                            : <span></span>
                    </span>
                            <span class="text query_time" title="Fri Nov 06 2026 20:53:13 GMT+0700 (Western Indonesia Time)">
            Waktu eksekusi kueri
                            : <span>20:53:13</span>
                    </span>
            </div><div class="query highlighted"><span class="cm-keyword">SELECT</span>
    @@hostname <span class="cm-keyword">AS</span> hostname<span class="cm-punctuation">,</span>
    @@port <span class="cm-keyword">AS</span> port<span class="cm-punctuation">,</span>
    @@datadir <span class="cm-keyword">AS</span> lokasi_database<span class="cm-punctuation">,</span>
    @@version <span class="cm-keyword">AS</span> versi_mysql<span class="cm-punctuation">;</span></div></div><div class="message collapsed binded select successed" msgid="208163249560" targetdb="db_inventori_fitrah" targettable="barang"><div class="action_content">
                    <span class="action collapse">
            Tampilkan
                    </span>
                            <span class="action expand">
            Buka
                    </span>
                            <span class="action requery">
            Kueri ulang
                    </span>
                            <span class="action edit">
            Ubah
                    </span>
                            <span class="action explain">
            Jelaskan
                    </span>
                            <span class="action profiling">
            Profil
                    </span>
                            <span class="action bookmark">
            Bookmarks
                    </span>
                            <span class="text failed">
            Kueri gagal
                    </span>
                            <span class="text targetdb">
            Basis data
                            : <span>db_inventori_fitrah</span>
                    </span>
                            <span class="text query_time" title="Fri Nov 06 2026 21:05:13 GMT+0700 (Western Indonesia Time)">
            Waktu eksekusi kueri
                            : <span>21:5:13</span>
                    </span>
            </div><div class="query highlighted"><span class="cm-keyword">SELECT</span> <span class="cm-operator">*</span> <span class="cm-keyword">FROM</span> `barang`</div></div></div><!-- console_message_container -->
            <div class="query_input">
                <span class="console_query_input"><div class="CodeMirror cm-s-pma CodeMirror-wrap" translate="no" style="clip-path: inset(0px);"><div style="overflow: hidden; position: relative; width: 3px; height: 0px; top: 0px; left: 16px;"><textarea autocorrect="off" autocapitalize="off" spellcheck="false" tabindex="0" style="position: absolute; bottom: -1em; padding: 0px; width: 1000px; height: 1em; min-height: 1em; outline: none;"></textarea></div><div class="CodeMirror-vscrollbar" tabindex="-1" cm-not-content="true"><div style="min-width: 1px; height: 0px;"></div></div><div class="CodeMirror-hscrollbar" tabindex="-1" cm-not-content="true"><div style="height: 100%; min-height: 1px; width: 0px;"></div></div><div class="CodeMirror-scrollbar-filler" cm-not-content="true"></div><div class="CodeMirror-gutter-filler" cm-not-content="true"></div><div class="CodeMirror-scroll" tabindex="-1"><div class="CodeMirror-sizer" style="margin-left: 16px; margin-bottom: -15px; border-right-width: 35px; min-height: 20px; padding-right: 0px; padding-bottom: 0px;"><div style="position: relative; top: 0px;"><div class="CodeMirror-lines" role="presentation"><div role="presentation" style="position: relative; outline: none;"><div class="CodeMirror-measure"><span><span>​</span>x</span></div><div class="CodeMirror-measure"></div><div style="position: relative; z-index: 1;"></div><div class="CodeMirror-cursors"><div class="CodeMirror-cursor" style="left: 0px; top: 0px; height: 19.6875px;">&nbsp;</div></div><div class="CodeMirror-code" role="presentation"><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;"><span cm-text="">​</span></span></pre></div></div></div></div></div><div style="position: absolute; height: 35px; width: 1px; border-bottom: 0px solid transparent; top: 20px;"></div><div class="CodeMirror-gutters" style="height: 55px;"><div class="CodeMirror-gutter CodeMirror-lint-markers"></div></div></div></div></span>
            </div>
        </div><!-- message end -->
                <div class="mid_layer"></div>
                <div class="card ungrouped" id="debug_console">
            <div class="toolbar ">
                    <div class="button order order_asc active">
            
            <span>ascending</span>
        </div>
                            <div class="button order order_desc">
            
            <span>descending</span>
        </div>
                            <div class="text">
            
            <span>Order:</span>
        </div>
                            <div class="switch_button">
            
            <span>Men-Debug SQL</span>
        </div>
                            <div class="button order_by sort_count">
            
            <span>Jumlah</span>
        </div>
                            <div class="button order_by sort_exec active">
            
            <span>Execution order</span>
        </div>
                            <div class="button order_by sort_time">
            
            <span>Time taken</span>
        </div>
                            <div class="text">
            
            <span>Order by:</span>
        </div>
                            <div class="button group_queries">
            
            <span>Group queries</span>
        </div>
                            <div class="button ungroup_queries">
            
            <span>Ungroup queries</span>
        </div>
            </div>
            <div class="content debug" style="height: 98.248px;">
                <div class="message welcome binded">Terjadi beberapa kesalahan saat mendapatkan info debug SQL.</div>
                <div class="debugLog"></div>
            </div> <!-- Content -->
            <div class="templates">
                <div class="debug_query action_content">
                    <span class="action collapse">
            Tampilkan
                    </span>
                            <span class="action expand">
            Buka
                    </span>
                            <span class="action dbg_show_trace">
            Show trace
                    </span>
                            <span class="action dbg_hide_trace">
            Hide trace
                    </span>
                            <span class="text count hide">
            Jumlah
                            : <span></span>
                    </span>
                            <span class="text time">
            Time taken
                            : <span></span>
                    </span>
            </div>
            </div> <!-- Template -->
        </div> <!-- Debug SQL card -->
                    <div class="card" id="pma_bookmarks">
                <div class="toolbar ">
                    <div class="switch_button">
            
            <span>Bookmark</span>
        </div>
                            <div class="button refresh">
            
            <span>Segarkan</span>
        </div>
                            <div class="button add">
            
            <span>Tambah</span>
        </div>
            </div>
                <div class="content bookmark" style="height: 98.248px;">
                    <div class="message welcome binded">
    <span>Tidak ada penanda</span>
</div>

                </div>
                <div class="mid_layer"></div>
                <div class="card add">
                    <div class="toolbar ">
                    <div class="switch_button">
            
            <span>Tambah bookmark</span>
        </div>
            </div>
                    <div class="content add_bookmark" style="height: 101px;">
                        <div class="options">
                            <label>
                                Label: <input type="text" name="label">
                            </label>
                            <label>
                                Basis data target: <input type="text" name="targetdb">
                            </label>
                            <label>
                                <input type="checkbox" name="shared">Bagikan bookmark                            </label>
                            <button class="btn btn-primary" type="submit" name="submit">Oke</button>
                        </div> <!-- options -->
                        <div class="query_input">
                            <span class="bookmark_add_input"><div class="CodeMirror cm-s-pma CodeMirror-wrap" translate="no" style="clip-path: inset(0px);"><div style="overflow: hidden; position: relative; width: 3px; height: 0px; top: 0px; left: 16px;"><textarea autocorrect="off" autocapitalize="off" spellcheck="false" tabindex="0" style="position: absolute; bottom: -1em; padding: 0px; width: 1000px; height: 1em; min-height: 1em; outline: none;"></textarea></div><div class="CodeMirror-vscrollbar" tabindex="-1" cm-not-content="true"><div style="min-width: 1px; height: 0px;"></div></div><div class="CodeMirror-hscrollbar" tabindex="-1" cm-not-content="true"><div style="height: 100%; min-height: 1px; width: 0px;"></div></div><div class="CodeMirror-scrollbar-filler" cm-not-content="true"></div><div class="CodeMirror-gutter-filler" cm-not-content="true"></div><div class="CodeMirror-scroll" tabindex="-1"><div class="CodeMirror-sizer" style="margin-left: 16px; margin-bottom: -15px; border-right-width: 35px; min-height: 20px; padding-right: 0px; padding-bottom: 0px;"><div style="position: relative; top: 0px;"><div class="CodeMirror-lines" role="presentation"><div role="presentation" style="position: relative; outline: none;"><div class="CodeMirror-measure"><pre class="CodeMirror-line-like"><span>xxxxxxxxxx</span></pre></div><div class="CodeMirror-measure"></div><div style="position: relative; z-index: 1;"></div><div class="CodeMirror-cursors"><div class="CodeMirror-cursor" style="left: 0px; top: 0px; height: 19.6875px;">&nbsp;</div></div><div class="CodeMirror-code" role="presentation"><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;"><span cm-text="">​</span></span></pre></div></div></div></div></div><div style="position: absolute; height: 35px; width: 1px; border-bottom: 0px solid transparent; top: 20px;"></div><div class="CodeMirror-gutters" style="height: 55px;"><div class="CodeMirror-gutter CodeMirror-lint-markers"></div></div></div></div></span>
                        </div>
                    </div>
                </div> <!-- Add bookmark card -->
            </div> <!-- Bookmarks card -->
                        <div class="card" id="pma_console_options">
            <div class="toolbar ">
                    <div class="switch_button">
            
            <span>Opsi</span>
        </div>
                            <div class="button default">
            
            <span>Kembalikan nilai bawaan</span>
        </div>
            </div>
            <div class="content" style="height: 101px;">
                <label>
                    <input type="checkbox" name="always_expand">Selalu tampilkan pesan kueri                </label>
                <br>
                <label>
                    <input type="checkbox" name="start_history">Tampilkan riwayat kueri di awal                </label>
                <br>
                <label>
                    <input type="checkbox" name="current_query">Show current browsing query                </label>
                <br>
                <label>
                    <input type="checkbox" name="enter_executes">
                        Execute queries on Enter and insert new line with Shift+Enter. To make this permanent, view settings.                </label>
                <br>
                <label>
                    <input type="checkbox" name="dark_theme">Beralih ke tema gelap                </label>
                <br>
            </div>
        </div> <!-- Options card -->
        <div class="templates">
                        <div class="query_actions">
                    <span class="action collapse">
            Tampilkan
                    </span>
                            <span class="action expand">
            Buka
                    </span>
                            <span class="action requery">
            Kueri ulang
                    </span>
                            <span class="action edit">
            Ubah
                    </span>
                            <span class="action explain">
            Jelaskan
                    </span>
                            <span class="action profiling">
            Profil
                    </span>
                            <span class="action bookmark">
            Bookmarks
                    </span>
                            <span class="text failed">
            Kueri gagal
                    </span>
                            <span class="text targetdb">
            Basis data
                            : <span></span>
                    </span>
                            <span class="text query_time">
            Waktu eksekusi kueri
                            : <span></span>
                    </span>
            </div>
        </div>
    </div> <!-- #console end -->
</div> <!-- #console_container end -->


  <div id="page_content"><div id="page_settings_modal"><div class="page_settings"><form method="post" action="http://localhost/phpmyadmin/index.php?route=%2Fdatabase%2Fstructure&amp;db=db_inventori_fitrah&amp;server=1" class="config-form disableAjax">
  <input type="hidden" name="tab_hash" value="">
      <input type="hidden" name="check_page_refresh" id="check_page_refresh" value="">
    <input type="hidden" name="token" value="2e7558593b5a5173314b356f4a394569">
  <input type="hidden" name="submit_save" value="DbStructure">

  <ul class="nav nav-tabs" id="configFormDisplayTab" role="tablist">
          <li class="nav-item" role="presentation">
        <a class="nav-link active" id="DbStructure-tab" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#DbStructure" data-bs-toggle="tab" role="tab" aria-controls="DbStructure" aria-selected="true">Stuktur basis data</a>
      </li>
      </ul>
  <div class="tab-content">
          <div class="tab-pane fade show active" id="DbStructure" role="tabpanel" aria-labelledby="DbStructure-tab">
        <div class="card border-top-0">
          <div class="card-body">
            <h5 class="card-title visually-hidden">Stuktur basis data</h5>
                          <h6 class="card-subtitle mb-2 text-muted">Pilih detail mana untuk menampilkan struktur database (daftar tabel).</h6>
            
            <fieldset class="optbox">
              <legend>Stuktur basis data</legend>

                            
              <table class="table table-borderless">
                <tbody><tr>
  <th>
    <label for="ShowDbStructureCharset">Tampilkan tabel set karakter</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_ShowDbStructureCharset" target="documentation"><img src="./db_inventori_fitrah_files/dot.gif" title="Dokumentasi" alt="Dokumentasi" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Show or hide a column displaying the charset for all tables.</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="ShowDbStructureCharset" id="ShowDbStructureCharset">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#ShowDbStructureCharset" title="Kembalikan nilai bawaan" style="display: inline-block; opacity: 0.25;"><img src="./db_inventori_fitrah_files/dot.gif" title="Kembalikan nilai bawaan" alt="Kembalikan nilai bawaan" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="ShowDbStructureComment">Tampilkan komentar tabel</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_ShowDbStructureComment" target="documentation"><img src="./db_inventori_fitrah_files/dot.gif" title="Dokumentasi" alt="Dokumentasi" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Menampilkan atau menyembunyikan sebuah kolom yang menampilkan komentar untuk semua tabel.</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="ShowDbStructureComment" id="ShowDbStructureComment">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#ShowDbStructureComment" title="Kembalikan nilai bawaan" style="display: inline-block; opacity: 0.25;"><img src="./db_inventori_fitrah_files/dot.gif" title="Kembalikan nilai bawaan" alt="Kembalikan nilai bawaan" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="ShowDbStructureCreation">Tampilkan timestamp pembuatan</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_ShowDbStructureCreation" target="documentation"><img src="./db_inventori_fitrah_files/dot.gif" title="Dokumentasi" alt="Dokumentasi" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Menampilkan atau menyembunyikan sebuah kolom yang menampilkan timestamp pembuatan untuk semua tabel.</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="ShowDbStructureCreation" id="ShowDbStructureCreation">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#ShowDbStructureCreation" title="Kembalikan nilai bawaan" style="display: inline-block; opacity: 0.25;"><img src="./db_inventori_fitrah_files/dot.gif" title="Kembalikan nilai bawaan" alt="Kembalikan nilai bawaan" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="ShowDbStructureLastUpdate">Show last update timestamp</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_ShowDbStructureLastUpdate" target="documentation"><img src="./db_inventori_fitrah_files/dot.gif" title="Dokumentasi" alt="Dokumentasi" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Menampilkan atau menyembunyikan kolom yang menampilkan timestamp Terakhir diperbaharui untuk semua tabel.</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="ShowDbStructureLastUpdate" id="ShowDbStructureLastUpdate">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#ShowDbStructureLastUpdate" title="Kembalikan nilai bawaan" style="display: inline-block; opacity: 0.25;"><img src="./db_inventori_fitrah_files/dot.gif" title="Kembalikan nilai bawaan" alt="Kembalikan nilai bawaan" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="ShowDbStructureLastCheck">Tampilkan cek timestamp terakhir</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_ShowDbStructureLastCheck" target="documentation"><img src="./db_inventori_fitrah_files/dot.gif" title="Dokumentasi" alt="Dokumentasi" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Menampilkan atau menyembunyikan kolom yang menampilkan cek timestamp terakhir untuk semua tabel.</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="ShowDbStructureLastCheck" id="ShowDbStructureLastCheck">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#ShowDbStructureLastCheck" title="Kembalikan nilai bawaan" style="display: inline-block; opacity: 0.25;"><img src="./db_inventori_fitrah_files/dot.gif" title="Kembalikan nilai bawaan" alt="Kembalikan nilai bawaan" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>

              </tbody></table>
            </fieldset>
          </div>

                  </div>
      </div>
      </div>
</form>

<script type="text/javascript">
  if (typeof configInlineParams === 'undefined' || !Array.isArray(configInlineParams)) {
    configInlineParams = [];
  }
  configInlineParams.push(function () {
    ;

    $.extend(Messages, {
      'error_nan_p': 'Bukan\u0020angka\u0020positif\u0021',
      'error_nan_nneg': 'Bukan\u0020angka\u0020non\u002Dnegatif\u0021',
      'error_incorrect_port': 'Bukan\u0020angka\u0020port\u0020yang\u0020sah\u0021',
      'error_invalid_value': 'Nilai\u0020yang\u0020salah\u0021',
      'error_value_lte': 'Nilai\u0020harus\u0020sama\u0020dengan\u0020atau\u0020lebih\u0020kecil\u0020dari\u0020\u0025s\u0021',
    });

    $.extend(defaultValues, {
      'ShowDbStructureCharset': false,
      'ShowDbStructureComment': false,
      'ShowDbStructureCreation': false,
      'ShowDbStructureLastUpdate': false,
      'ShowDbStructureLastCheck': false
    });
  });
  if (typeof configScriptLoaded !== 'undefined' && configInlineParams) {
    loadInlineConfig();
  }
</script>
</div></div>
  <div id="tableslistcontainer">
    

    <div class="card mb-3" id="tableFilter">
  <div class="card-header">Filters</div>
  <div class="card-body row row-cols-lg-auto gy-1 gx-3 align-items-center">
    <label class="col-12 col-form-label" for="filterText">Mengandung kata:</label>
    <div class="col-12">
      <input class="form-control" name="filterText" type="text" id="filterText" value="">
    </div>
  </div>
</div>
<form method="post" action="http://localhost/phpmyadmin/index.php?route=/database/structure" name="tablesForm" id="tablesForm">
<input type="hidden" name="db" value="db_inventori_fitrah"><input type="hidden" name="token" value="2e7558593b5a5173314b356f4a394569">
<div class="table-responsive">
<table class="table table-striped table-hover table-sm w-auto data">
    <thead>
        <tr>
            <th class="d-print-none"></th>
            <th><a href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah&amp;pos=0&amp;sort=table&amp;sort_order=DESC" title="Urutan" onmouseover="$('.sort_arrow').toggle();" onmouseout="$('.sort_arrow').toggle();">Tabel <img src="./db_inventori_fitrah_files/dot.gif" title="" alt="Menaik" class="icon ic_s_asc sort_arrow"> <img src="./db_inventori_fitrah_files/dot.gif" title="" alt="Menurun" class="icon ic_s_desc sort_arrow hide"></a></th>
            
                                                                                            <th colspan="7" class="d-print-none">
                Tindakan            </th>
                        <th>
                <a href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah&amp;pos=0&amp;sort=records&amp;sort_order=DESC" title="Urutan">Baris</a>
                <span class="pma_hint"><img src="./db_inventori_fitrah_files/dot.gif" title="" alt="" class="icon ic_b_help"><span class="hide">May be approximate. Click on the number to get the exact count. See <a href="http://localhost/phpmyadmin/doc/html/faq.html#faq3-11" target="documentation">FAQ 3.11</a>.</span></span>
            </th>
                            <th><a href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah&amp;pos=0&amp;sort=type&amp;sort_order=ASC" title="Urutan">Jenis</a></th>
                <th><a href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah&amp;pos=0&amp;sort=collation&amp;sort_order=ASC" title="Urutan">Penyortiran</a></th>
            
                                            <th><a href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah&amp;pos=0&amp;sort=size&amp;sort_order=DESC" title="Urutan">Ukuran</a></th>
                                <th><a href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah&amp;pos=0&amp;sort=overhead&amp;sort_order=DESC" title="Urutan">Beban</a></th>
            
            
            
            
            
                    </tr>
    </thead>
    <tbody>
            <tr id="row_tbl_1" data-filter-row="BARANG">
    <td class="text-center d-print-none">
        <input type="checkbox" name="selected_tbl[]" class="checkall" value="barang" id="checkbox_tbl_1">
    </td>
    <th>
        <a href="http://localhost/phpmyadmin/index.php?route=/sql&amp;db=db_inventori_fitrah&amp;table=barang&amp;pos=0" title="">barang</a>
        
    </th>
    
                <td class="text-center d-print-none">
                                    <a id="177cbf2b2fda8daf8688bd68a5ea6e14_favorite_anchor" class="ajax favorite_table_anchor" href="http://localhost/phpmyadmin/index.php?route=/database/structure/favorite-table&amp;db=db_inventori_fitrah&amp;ajax_request=1&amp;favorite_table=barang&amp;add_favorite=1" title="Tambahkan ke favorit" data-favtargets="d699a4f173f1cab3bcf3b2ffb04d4c15">
    <span class="text-nowrap"><img src="./db_inventori_fitrah_files/dot.gif" title="" alt="" class="icon ic_b_no_favorite">&nbsp;</span>
</a>
        </td>
    
    <td class="text-center d-print-none">
        <a href="http://localhost/phpmyadmin/index.php?route=/sql&amp;db=db_inventori_fitrah&amp;table=barang&amp;pos=0">
          <span class="text-nowrap"><img src="./db_inventori_fitrah_files/dot.gif" title="Jelajahi" alt="Jelajahi" class="icon ic_bd_browse">&nbsp;Jelajahi</span>
        </a>
    </td>
    <td class="text-center d-print-none">
        <a href="http://localhost/phpmyadmin/index.php?route=/table/structure&amp;db=db_inventori_fitrah&amp;table=barang">
          <span class="text-nowrap"><img src="./db_inventori_fitrah_files/dot.gif" title="Struktur" alt="Struktur" class="icon ic_b_props">&nbsp;Struktur</span>
        </a>
    </td>
    <td class="text-center d-print-none">
        <a href="http://localhost/phpmyadmin/index.php?route=/table/search&amp;db=db_inventori_fitrah&amp;table=barang">
          <span class="text-nowrap"><img src="./db_inventori_fitrah_files/dot.gif" title="Cari" alt="Cari" class="icon ic_bd_select">&nbsp;Cari</span>
        </a>
    </td>

            <td class="insert_table text-center d-print-none">
            <a href="http://localhost/phpmyadmin/index.php?route=/table/change&amp;db=db_inventori_fitrah&amp;table=barang"><span class="text-nowrap"><img src="./db_inventori_fitrah_files/dot.gif" title="Tambahkan" alt="Tambahkan" class="icon ic_b_insrow">&nbsp;Tambahkan</span></a>
        </td>
                  <td class="text-center d-print-none">
                <a class="truncate_table_anchor ajax" href="http://localhost/phpmyadmin/index.php?route=/sql" data-post="db=db_inventori_fitrah&amp;table=barang&amp;sql_query=TRUNCATE+%60barang%60&amp;message_to_show=Tabel%2Bbarang%2Btelah%2Bdikosongkan.">
                  <span class="text-nowrap"><img src="./db_inventori_fitrah_files/dot.gif" title="Kosongkan" alt="Kosongkan" class="icon ic_bd_empty">&nbsp;Kosongkan</span>
                </a>
          </td>
                <td class="text-center d-print-none">
            <a class="ajax drop_table_anchor" href="http://localhost/phpmyadmin/index.php?route=/sql" data-post="db=db_inventori_fitrah&amp;table=barang&amp;reload=1&amp;purge=1&amp;sql_query=DROP+TABLE+%60barang%60&amp;message_to_show=Tabel+barang+telah+terhapus.">
                <span class="text-nowrap"><img src="./db_inventori_fitrah_files/dot.gif" title="Hapus" alt="Hapus" class="icon ic_b_drop">&nbsp;Hapus</span>
            </a>
        </td>
    
                    
                <td class="value tbl_rows font-monospace text-end" data-table="barang">
                            0
                        
        </td>

                    <td class="text-nowrap">
                                    InnoDB
                            </td>
                            <td class="text-nowrap">
                    <dfn title="Unikode (UCA 4.0.0), tidak peka huruf kapital">utf8mb4_general_ci</dfn>

                </td>
                    
                    <td class="value tbl_size font-monospace text-end">
                <a href="http://localhost/phpmyadmin/index.php?route=/table/structure&amp;db=db_inventori_fitrah&amp;table=barang#showusage">
                    <span>16.0</span>&nbsp;<span class="unit">KB</span>
                </a>
            </td>
            <td class="value tbl_overhead font-monospace text-end">
                -
            </td>
        
                            
        
        
        
        
    </tr>
        </tbody>
            <tfoot id="tbl_summary_row">
<tr>
    <th class="d-print-none"></th>
    <th class="tbl_num text-nowrap">
                1 tabel
    </th>
                <th colspan="7" class="d-print-none">Jumlah</th>
                                                <th class="value tbl_rows font-monospace text-end">0</th>
                                    <th class="text-center">
            <dfn title="InnoDB adalah mesin penyimpanan utama pada server MySQL ini.">
                InnoDB
            </dfn>
        </th>
        <th>
                            <dfn title="Unikode (UCA 4.0.0), tidak peka huruf kapital (Bawaan)">
                    utf8mb4_general_ci
                </dfn>
                    </th>
    
                                    <th class="value tbl_size font-monospace text-end">16.0 KB</th>

                                <th class="value tbl_overhead font-monospace text-end">0 B</th>
    
                    </tr>
</tfoot>
    </table>
</div>
  <div class="clearfloat d-print-none">
    <img class="selectallarrow" src="./db_inventori_fitrah_files/arrow_ltr.png" width="38" height="22" alt="Dengan pilihan:">
    <input type="checkbox" id="tablesForm_checkall" class="checkall_box" title="Pilih Semua">
    <label for="tablesForm_checkall">Pilih Semua</label>
        <select name="submit_mult" style="margin: 0 3em 0 3em;">
        <option value="Dengan pilihan:" selected="selected">Dengan pilihan:</option>
        <option value="copy_tbl">Copy table</option>
        <option value="show_create">Show create</option>
        <option value="export">Ekspor</option>
                    <optgroup label="Hapus data atau tabel">
                <option value="empty_tbl">Kosongkan</option>
                <option value="drop_tbl">Hapus</option>
            </optgroup>
            <optgroup label="Pemeliharaan tabel">
                <option value="analyze_tbl">Analisis tabel</option>
                <option value="check_tbl">Periksa tabel</option>
                <option value="checksum_tbl">Checksum table</option>
                <option value="optimize_tbl">Optimalkan tabel</option>
                <option value="repair_tbl">Perbaiki tabel</option>
            </optgroup>
            <optgroup label="Prefix">
                <option value="add_prefix_tbl">Tambahkan prefiks untuk tabel</option>
                <option value="replace_prefix_tbl">Ganti prefiks tabel</option>
                <option value="copy_tbl_change_prefix">Salin tabel dengan prefiks</option>
            </optgroup>
                            <optgroup label="Tengah kolom">
                <option value="sync_unique_columns_central_list">Add columns to central list</option>
                <option value="delete_unique_columns_central_list">Remove columns from central list</option>
                <option value="make_consistent_with_central_list">Make consistent with central list</option>
            </optgroup>
            </select>
    
</div>

  <div class="modal fade" id="makeConsistentWithCentralListModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="makeConsistentWithCentralListModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="makeConsistentWithCentralListModalLabel">Anda yakin?</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Batal"></button>
        </div>
        <div class="modal-body">
          Tindakan ini mungkin mengubah beberapa definisi kolom.<br>Anda yakin ingin melanjutkan?
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
          <button type="button" class="btn btn-primary" id="makeConsistentWithCentralListContinue">Lanjutkan</button>
        </div>
      </div>
    </div>
  </div>
</form>
  <div class="modal fade" id="bulkActionModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="bulkActionLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="bulkActionLabel"></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Batal"></button>
      </div>
      <div class="modal-body"></div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
        <button type="button" class="btn btn-primary" id="bulkActionContinue">Lanjutkan</button>
      </div>
    </div>
  </div>
</div>

    
  </div>
  <hr>
  <p class="d-print-none">
    <button type="button" class="btn btn-link p-0 jsPrintButton"><span class="text-nowrap"><img src="./db_inventori_fitrah_files/dot.gif" title="Cetak" alt="Cetak" class="icon ic_b_print">&nbsp;Cetak</span></button>
    <a href="http://localhost/phpmyadmin/index.php?route=/database/data-dictionary&amp;db=db_inventori_fitrah&amp;goto=index.php%3Froute%3D%2Fdatabase%2Fstructure">
      <span class="text-nowrap"><img src="./db_inventori_fitrah_files/dot.gif" title="Kamus data" alt="Kamus data" class="icon ic_b_tblanalyse">&nbsp;Kamus data</span>
    </a>
  </p>

  <form id="createTableMinimalForm" method="post" action="http://localhost/phpmyadmin/index.php?route=/table/create" class="card d-print-none lock-page">
  <input type="hidden" name="db" value="db_inventori_fitrah"><input type="hidden" name="token" value="2e7558593b5a5173314b356f4a394569">
  <div class="card-header"><span class="text-nowrap"><img src="./db_inventori_fitrah_files/dot.gif" title="Create new table" alt="Create new table" class="icon ic_b_table_add">&nbsp;Create new table</span></div>
  <div class="card-body row row-cols-lg-auto g-3">
    <div class="col-12">
      <label for="createTableNameInput" class="form-label">Nama tabel</label>
      <input type="text" class="form-control" name="table" id="createTableNameInput" maxlength="64" required="">
    </div>
    <div class="col-12">
      <label for="createTableNumFieldsInput" class="form-label">Jumlah kolom</label>
      <input type="number" class="form-control" name="num_fields" id="createTableNumFieldsInput" min="1" value="4" required="">
    </div>
    <div class="col-12 align-self-lg-end">
      <input class="btn btn-primary" type="submit" value="Buat">
    </div>
  </div>
</form>

</div>

      <div id="selflink" class="d-print-none">
      <a href="http://localhost/phpmyadmin/index.php?route=%2Fdatabase%2Fstructure&amp;db=db_inventori_fitrah&amp;server=1" title="Buka jendela phpMyAdmin baru" target="_blank" rel="noopener noreferrer">
                  <img src="./db_inventori_fitrah_files/dot.gif" title="Buka jendela phpMyAdmin baru" alt="Buka jendela phpMyAdmin baru" class="icon ic_window-new">
              </a>
    </div>
  
  

  



  
  
  

<div role="log" aria-live="assertive" aria-relevant="additions" class="ui-helper-hidden-accessible"></div><div role="log" aria-live="assertive" aria-relevant="additions" class="ui-helper-hidden-accessible"></div><div tabindex="-1" role="dialog" class="ui-dialog ui-corner-all ui-widget ui-widget-content ui-front ui-dialog-buttons ui-draggable ui-resizable" aria-describedby="pma_navigation_settings" aria-labelledby="ui-id-14" style="position: fixed; height: auto; width: 700px; top: 25.7192px; left: 333px; display: none;"><div class="ui-dialog-titlebar ui-corner-all ui-widget-header ui-helper-clearfix ui-draggable-handle"><span id="ui-id-14" class="ui-dialog-title">Pengaturan Terkait dengan Halaman</span><button type="button" class="ui-dialog-titlebar-close btn-close"></button></div><div id="pma_navigation_settings" class="ui-dialog-content ui-widget-content" style="display: block; width: auto; min-height: 134.734px; max-height: 487.375px; height: auto;"><div class="page_settings"><form method="post" action="http://localhost/phpmyadmin/index.php?route=%2Fdatabase%2Fstructure&amp;db=db_inventori_fitrah&amp;server=1" class="config-form disableAjax">
  <input type="hidden" name="tab_hash" value="">
      <input type="hidden" name="check_page_refresh" id="check_page_refresh" value="1">
    <input type="hidden" name="token" value="2e7558593b5a5173314b356f4a394569">
  <input type="hidden" name="submit_save" value="Navi">

  <ul class="nav nav-tabs" id="configFormDisplayTab" role="tablist">
          <li class="nav-item" role="presentation">
        <a class="nav-link active" id="Navi_panel-tab" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#Navi_panel" data-bs-toggle="tab" role="tab" aria-controls="Navi_panel" aria-selected="true">Panel navigasi</a>
      </li>
          <li class="nav-item" role="presentation">
        <a class="nav-link" id="Navi_tree-tab" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#Navi_tree" data-bs-toggle="tab" role="tab" aria-controls="Navi_tree" aria-selected="false" tabindex="-1">Panel navigasi</a>
      </li>
          <li class="nav-item" role="presentation">
        <a class="nav-link" id="Navi_servers-tab" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#Navi_servers" data-bs-toggle="tab" role="tab" aria-controls="Navi_servers" aria-selected="false" tabindex="-1">Server</a>
      </li>
          <li class="nav-item" role="presentation">
        <a class="nav-link" id="Navi_databases-tab" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#Navi_databases" data-bs-toggle="tab" role="tab" aria-controls="Navi_databases" aria-selected="false" tabindex="-1">Basis data</a>
      </li>
          <li class="nav-item" role="presentation">
        <a class="nav-link" id="Navi_tables-tab" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#Navi_tables" data-bs-toggle="tab" role="tab" aria-controls="Navi_tables" aria-selected="false" tabindex="-1">Tabel</a>
      </li>
      </ul>
  <div class="tab-content">
          <div class="tab-pane fade show active" id="Navi_panel" role="tabpanel" aria-labelledby="Navi_panel-tab">
        <div class="card border-top-0">
          <div class="card-body">
            <h5 class="card-title visually-hidden">Panel navigasi</h5>
                          <h6 class="card-subtitle mb-2 text-muted">Atur tampilan panel navigasi.</h6>
            
            <fieldset class="optbox">
              <legend>Panel navigasi</legend>

                            
              <table class="table table-borderless">
                <tbody><tr>
  <th>
    <label for="ShowDatabasesNavigationAsTree">Tampilkan cabang navigasi databases</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_ShowDatabasesNavigationAsTree" target="documentation"><img src="./db_inventori_fitrah_files/dot.gif" title="Dokumentasi" alt="Dokumentasi" class="icon ic_b_help"></a>
      </span>
    
    
          <small>di panel navigasi, timpa cabang database serta selectornya</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="ShowDatabasesNavigationAsTree" id="ShowDatabasesNavigationAsTree" checked="">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#ShowDatabasesNavigationAsTree" title="Kembalikan nilai bawaan" style="display: inline-block; opacity: 0.25;"><img src="./db_inventori_fitrah_files/dot.gif" title="Kembalikan nilai bawaan" alt="Kembalikan nilai bawaan" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NavigationLinkWithMainPanel">Link ke panel utama</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationLinkWithMainPanel" target="documentation"><img src="./db_inventori_fitrah_files/dot.gif" title="Dokumentasi" alt="Dokumentasi" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Menghubungkan dengan panel utama untuk menyoroti database atau tabel yang saat ini.</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="NavigationLinkWithMainPanel" id="NavigationLinkWithMainPanel" checked="">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#NavigationLinkWithMainPanel" title="Kembalikan nilai bawaan" style="display: inline-block; opacity: 0.25;"><img src="./db_inventori_fitrah_files/dot.gif" title="Kembalikan nilai bawaan" alt="Kembalikan nilai bawaan" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NavigationDisplayLogo">Tampilkan logo</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationDisplayLogo" target="documentation"><img src="./db_inventori_fitrah_files/dot.gif" title="Dokumentasi" alt="Dokumentasi" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Tampilkan logo di panel navigasi.</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="NavigationDisplayLogo" id="NavigationDisplayLogo" checked="">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#NavigationDisplayLogo" title="Kembalikan nilai bawaan" style="display: inline-block; opacity: 0.25;"><img src="./db_inventori_fitrah_files/dot.gif" title="Kembalikan nilai bawaan" alt="Kembalikan nilai bawaan" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NavigationLogoLink">URL tautan logo</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationLogoLink" target="documentation"><img src="./db_inventori_fitrah_files/dot.gif" title="Dokumentasi" alt="Dokumentasi" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Arahkan URL untuk logo pada panel navigasi.</small>
      </th>

  <td>
          <input type="text" name="NavigationLogoLink" id="NavigationLogoLink" value="index.php" class="w-75">
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#NavigationLogoLink" title="Kembalikan nilai bawaan" style="display: inline-block; opacity: 0.25;"><img src="./db_inventori_fitrah_files/dot.gif" title="Kembalikan nilai bawaan" alt="Kembalikan nilai bawaan" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NavigationLogoLinkWindow">Sasaran tautan logo</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationLogoLinkWindow" target="documentation"><img src="./db_inventori_fitrah_files/dot.gif" title="Dokumentasi" alt="Dokumentasi" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Open the linked page in the main window (<code>main</code>) or in a new one (<code>new</code>).</small>
      </th>

  <td>
          <select name="NavigationLogoLinkWindow" id="NavigationLogoLinkWindow" class="w-75">
                            <option value="main" selected="">main</option>
                            <option value="new">new</option>
              </select>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#NavigationLogoLinkWindow" title="Kembalikan nilai bawaan" style="display: inline-block; opacity: 0.25;"><img src="./db_inventori_fitrah_files/dot.gif" title="Kembalikan nilai bawaan" alt="Kembalikan nilai bawaan" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NavigationTreePointerEnable">Aktifkan penyorotan</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreePointerEnable" target="documentation"><img src="./db_inventori_fitrah_files/dot.gif" title="Dokumentasi" alt="Dokumentasi" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Sorot server yang dikenai kursor.</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="NavigationTreePointerEnable" id="NavigationTreePointerEnable" checked="">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#NavigationTreePointerEnable" title="Kembalikan nilai bawaan" style="display: inline-block; opacity: 0.25;"><img src="./db_inventori_fitrah_files/dot.gif" title="Kembalikan nilai bawaan" alt="Kembalikan nilai bawaan" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="FirstLevelNavigationItems">Item maksimum di tingkat pertama</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_FirstLevelNavigationItems" target="documentation"><img src="./db_inventori_fitrah_files/dot.gif" title="Dokumentasi" alt="Dokumentasi" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Jumlah item yang dapat ditampilkan pada setiap halaman dari cabang navigasi.</small>
      </th>

  <td>
          <input type="number" name="FirstLevelNavigationItems" id="FirstLevelNavigationItems" value="100" class="">
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#FirstLevelNavigationItems" title="Kembalikan nilai bawaan" style="display: inline-block; opacity: 0.25;"><img src="./db_inventori_fitrah_files/dot.gif" title="Kembalikan nilai bawaan" alt="Kembalikan nilai bawaan" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NavigationTreeDisplayItemFilterMinimum">Jumlah minimum item yang ditampilkan di kotak tabel filter</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeDisplayItemFilterMinimum" target="documentation"><img src="./db_inventori_fitrah_files/dot.gif" title="Dokumentasi" alt="Dokumentasi" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Tentukan jumlah minimum item (tabel, view, routines dan event) untuk menampilkan kotak filter.</small>
      </th>

  <td>
          <input type="number" name="NavigationTreeDisplayItemFilterMinimum" id="NavigationTreeDisplayItemFilterMinimum" value="30" class="">
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#NavigationTreeDisplayItemFilterMinimum" title="Kembalikan nilai bawaan" style="display: inline-block; opacity: 0.25;"><img src="./db_inventori_fitrah_files/dot.gif" title="Kembalikan nilai bawaan" alt="Kembalikan nilai bawaan" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NumRecentTables">Tabel yang terakhir digunakan</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NumRecentTables" target="documentation"><img src="./db_inventori_fitrah_files/dot.gif" title="Dokumentasi" alt="Dokumentasi" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Jumlah maksimum tabel yang terakhir digunakan; atur 0 untuk menonaktifkannya.</small>
      </th>

  <td>
          <input type="number" name="NumRecentTables" id="NumRecentTables" value="10" class="">
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#NumRecentTables" title="Kembalikan nilai bawaan" style="display: inline-block; opacity: 0.25;"><img src="./db_inventori_fitrah_files/dot.gif" title="Kembalikan nilai bawaan" alt="Kembalikan nilai bawaan" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NumFavoriteTables">Tabel favorit</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NumFavoriteTables" target="documentation"><img src="./db_inventori_fitrah_files/dot.gif" title="Dokumentasi" alt="Dokumentasi" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Jumlah maksimum tabel favorit; atur 0 untuk menonaktifkannya.</small>
      </th>

  <td>
          <input type="number" name="NumFavoriteTables" id="NumFavoriteTables" value="10" class="">
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#NumFavoriteTables" title="Kembalikan nilai bawaan" style="display: inline-block; opacity: 0.25;"><img src="./db_inventori_fitrah_files/dot.gif" title="Kembalikan nilai bawaan" alt="Kembalikan nilai bawaan" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NavigationWidth">Lebar panel navigasi</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationWidth" target="documentation"><img src="./db_inventori_fitrah_files/dot.gif" title="Dokumentasi" alt="Dokumentasi" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Setel ke 0 untuk menutup panel navigasi.</small>
      </th>

  <td>
          <input type="number" name="NavigationWidth" id="NavigationWidth" value="240" class="">
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#NavigationWidth" title="Kembalikan nilai bawaan" style="display: inline-block; opacity: 0.25;"><img src="./db_inventori_fitrah_files/dot.gif" title="Kembalikan nilai bawaan" alt="Kembalikan nilai bawaan" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>

              </tbody></table>
            </fieldset>
          </div>

                  </div>
      </div>
          <div class="tab-pane fade" id="Navi_tree" role="tabpanel" aria-labelledby="Navi_tree-tab">
        <div class="card border-top-0">
          <div class="card-body">
            <h5 class="card-title visually-hidden">Panel navigasi</h5>
                          <h6 class="card-subtitle mb-2 text-muted">Atur panel navigasi.</h6>
            
            <fieldset class="optbox">
              <legend>Panel navigasi</legend>

                            
              <table class="table table-borderless">
                <tbody><tr>
  <th>
    <label for="MaxNavigationItems">Item maksimal di cabang</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_MaxNavigationItems" target="documentation"><img src="./db_inventori_fitrah_files/dot.gif" title="Dokumentasi" alt="Dokumentasi" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Jumlah item yang dapat ditampilkan pada setiap halaman dari pohon navigasi.</small>
      </th>

  <td>
          <input type="number" name="MaxNavigationItems" id="MaxNavigationItems" value="50" class="">
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#MaxNavigationItems" title="Kembalikan nilai bawaan" style="display: inline-block; opacity: 0.25;"><img src="./db_inventori_fitrah_files/dot.gif" title="Kembalikan nilai bawaan" alt="Kembalikan nilai bawaan" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NavigationTreeEnableGrouping">Item Group di pohon</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeEnableGrouping" target="documentation"><img src="./db_inventori_fitrah_files/dot.gif" title="Dokumentasi" alt="Dokumentasi" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Mengelompokkan barang di cabang navigasi (ditentukan oleh pemisah yang didefinisikan di tab Database dan Tabel di atas).</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="NavigationTreeEnableGrouping" id="NavigationTreeEnableGrouping" checked="">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#NavigationTreeEnableGrouping" title="Kembalikan nilai bawaan" style="display: inline-block; opacity: 0.25;"><img src="./db_inventori_fitrah_files/dot.gif" title="Kembalikan nilai bawaan" alt="Kembalikan nilai bawaan" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NavigationTreeEnableExpansion">Bolehkan perluasan pohon navigasi</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeEnableExpansion" target="documentation"><img src="./db_inventori_fitrah_files/dot.gif" title="Dokumentasi" alt="Dokumentasi" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Apakah akan menonaktifkan kemungkinan ekspansi database atau tidak.</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="NavigationTreeEnableExpansion" id="NavigationTreeEnableExpansion" checked="">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#NavigationTreeEnableExpansion" title="Kembalikan nilai bawaan" style="display: inline-block; opacity: 0.25;"><img src="./db_inventori_fitrah_files/dot.gif" title="Kembalikan nilai bawaan" alt="Kembalikan nilai bawaan" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NavigationTreeShowTables">Tampilkan tabel pada cabang</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeShowTables" target="documentation"><img src="./db_inventori_fitrah_files/dot.gif" title="Dokumentasi" alt="Dokumentasi" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Apakah akan menampilkan tabel di bawah database di pohon navigasi</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="NavigationTreeShowTables" id="NavigationTreeShowTables" checked="">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#NavigationTreeShowTables" title="Kembalikan nilai bawaan" style="display: inline-block; opacity: 0.25;"><img src="./db_inventori_fitrah_files/dot.gif" title="Kembalikan nilai bawaan" alt="Kembalikan nilai bawaan" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NavigationTreeShowViews">Tampilkan Views dalam bentuk bercabang</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeShowViews" target="documentation"><img src="./db_inventori_fitrah_files/dot.gif" title="Dokumentasi" alt="Dokumentasi" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Apakah menampilkan views di bawah database di navigation tree</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="NavigationTreeShowViews" id="NavigationTreeShowViews" checked="">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#NavigationTreeShowViews" title="Kembalikan nilai bawaan" style="display: inline-block; opacity: 0.25;"><img src="./db_inventori_fitrah_files/dot.gif" title="Kembalikan nilai bawaan" alt="Kembalikan nilai bawaan" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NavigationTreeShowFunctions">Tampilkan Fungsi dalam bentuk bercabang</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeShowFunctions" target="documentation"><img src="./db_inventori_fitrah_files/dot.gif" title="Dokumentasi" alt="Dokumentasi" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Apakah akan menampilkan fungsi di bawah database di navigation tree</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="NavigationTreeShowFunctions" id="NavigationTreeShowFunctions" checked="">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#NavigationTreeShowFunctions" title="Kembalikan nilai bawaan" style="display: inline-block; opacity: 0.25;"><img src="./db_inventori_fitrah_files/dot.gif" title="Kembalikan nilai bawaan" alt="Kembalikan nilai bawaan" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NavigationTreeShowProcedures">Tampilkan prosedur di percabangan</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeShowProcedures" target="documentation"><img src="./db_inventori_fitrah_files/dot.gif" title="Dokumentasi" alt="Dokumentasi" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Apakah akan menampilkan prosedur di bawah database di pohon navigasi</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="NavigationTreeShowProcedures" id="NavigationTreeShowProcedures" checked="">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#NavigationTreeShowProcedures" title="Kembalikan nilai bawaan" style="display: inline-block; opacity: 0.25;"><img src="./db_inventori_fitrah_files/dot.gif" title="Kembalikan nilai bawaan" alt="Kembalikan nilai bawaan" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NavigationTreeShowEvents">Tunjukkan events dalam pohon</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeShowEvents" target="documentation"><img src="./db_inventori_fitrah_files/dot.gif" title="Dokumentasi" alt="Dokumentasi" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Entah untuk menampilkan events di bawah database di navigation tree</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="NavigationTreeShowEvents" id="NavigationTreeShowEvents" checked="">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#NavigationTreeShowEvents" title="Kembalikan nilai bawaan" style="display: inline-block; opacity: 0.25;"><img src="./db_inventori_fitrah_files/dot.gif" title="Kembalikan nilai bawaan" alt="Kembalikan nilai bawaan" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NavigationTreeAutoexpandSingleDb">Expand single database</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeAutoexpandSingleDb" target="documentation"><img src="./db_inventori_fitrah_files/dot.gif" title="Dokumentasi" alt="Dokumentasi" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Whether to expand single database in the navigation tree automatically.</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="NavigationTreeAutoexpandSingleDb" id="NavigationTreeAutoexpandSingleDb" checked="">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#NavigationTreeAutoexpandSingleDb" title="Kembalikan nilai bawaan" style="display: inline-block; opacity: 0.25;"><img src="./db_inventori_fitrah_files/dot.gif" title="Kembalikan nilai bawaan" alt="Kembalikan nilai bawaan" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>

              </tbody></table>
            </fieldset>
          </div>

                  </div>
      </div>
          <div class="tab-pane fade" id="Navi_servers" role="tabpanel" aria-labelledby="Navi_servers-tab">
        <div class="card border-top-0">
          <div class="card-body">
            <h5 class="card-title visually-hidden">Server</h5>
                          <h6 class="card-subtitle mb-2 text-muted">Opsi tampilan server.</h6>
            
            <fieldset class="optbox">
              <legend>Server</legend>

                            
              <table class="table table-borderless">
                <tbody><tr>
  <th>
    <label for="NavigationDisplayServers">Tampilkan pilihan server</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationDisplayServers" target="documentation"><img src="./db_inventori_fitrah_files/dot.gif" title="Dokumentasi" alt="Dokumentasi" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Tampilkan pilihan server di bagian atas panel navigasi.</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="NavigationDisplayServers" id="NavigationDisplayServers" checked="">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#NavigationDisplayServers" title="Kembalikan nilai bawaan" style="display: inline-block; opacity: 0.25;"><img src="./db_inventori_fitrah_files/dot.gif" title="Kembalikan nilai bawaan" alt="Kembalikan nilai bawaan" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="DisplayServersList">Tampilkan server dalam bentuk daftar</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_DisplayServersList" target="documentation"><img src="./db_inventori_fitrah_files/dot.gif" title="Dokumentasi" alt="Dokumentasi" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Tampilkan daftar server dalam bentuk daftar dan bukan tarik-turun.</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="DisplayServersList" id="DisplayServersList">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#DisplayServersList" title="Kembalikan nilai bawaan" style="display: inline-block; opacity: 0.25;"><img src="./db_inventori_fitrah_files/dot.gif" title="Kembalikan nilai bawaan" alt="Kembalikan nilai bawaan" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>

              </tbody></table>
            </fieldset>
          </div>

                  </div>
      </div>
          <div class="tab-pane fade" id="Navi_databases" role="tabpanel" aria-labelledby="Navi_databases-tab">
        <div class="card border-top-0">
          <div class="card-body">
            <h5 class="card-title visually-hidden">Basis data</h5>
                          <h6 class="card-subtitle mb-2 text-muted">Opsi tampilan basis data.</h6>
            
            <fieldset class="optbox">
              <legend>Basis data</legend>

                            
              <table class="table table-borderless">
                <tbody><tr>
  <th>
    <label for="NavigationTreeDisplayDbFilterMinimum">Jumlah minimum database yang ditampilkan di kotak tabel filter</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeDisplayDbFilterMinimum" target="documentation"><img src="./db_inventori_fitrah_files/dot.gif" title="Dokumentasi" alt="Dokumentasi" class="icon ic_b_help"></a>
      </span>
    
    
      </th>

  <td>
          <input type="number" name="NavigationTreeDisplayDbFilterMinimum" id="NavigationTreeDisplayDbFilterMinimum" value="30" class="">
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#NavigationTreeDisplayDbFilterMinimum" title="Kembalikan nilai bawaan" style="display: inline-block; opacity: 0.25;"><img src="./db_inventori_fitrah_files/dot.gif" title="Kembalikan nilai bawaan" alt="Kembalikan nilai bawaan" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NavigationTreeDbSeparator">Pemisah hierarki basis data</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeDbSeparator" target="documentation"><img src="./db_inventori_fitrah_files/dot.gif" title="Dokumentasi" alt="Dokumentasi" class="icon ic_b_help"></a>
      </span>
    
    
          <small>String yang memisahkan basis data ke dalam tingkat hierarki yang berbeda.</small>
      </th>

  <td>
                <input type="text" size="25" name="NavigationTreeDbSeparator" id="NavigationTreeDbSeparator" value="_" class="">
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#NavigationTreeDbSeparator" title="Kembalikan nilai bawaan" style="display: inline-block; opacity: 0.25;"><img src="./db_inventori_fitrah_files/dot.gif" title="Kembalikan nilai bawaan" alt="Kembalikan nilai bawaan" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>

              </tbody></table>
            </fieldset>
          </div>

                  </div>
      </div>
          <div class="tab-pane fade" id="Navi_tables" role="tabpanel" aria-labelledby="Navi_tables-tab">
        <div class="card border-top-0">
          <div class="card-body">
            <h5 class="card-title visually-hidden">Tabel</h5>
                          <h6 class="card-subtitle mb-2 text-muted">Opsi tampilan tabel.</h6>
            
            <fieldset class="optbox">
              <legend>Tabel</legend>

                            
              <table class="table table-borderless">
                <tbody><tr>
  <th>
    <label for="NavigationTreeDefaultTabTable">Target ikon akses cepat</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeDefaultTabTable" target="documentation"><img src="./db_inventori_fitrah_files/dot.gif" title="Dokumentasi" alt="Dokumentasi" class="icon ic_b_help"></a>
      </span>
    
    
      </th>

  <td>
          <select name="NavigationTreeDefaultTabTable" id="NavigationTreeDefaultTabTable" class="w-75">
                            <option value="structure" selected="">Struktur</option>
                            <option value="sql">SQL</option>
                            <option value="search">Cari</option>
                            <option value="insert">Tambahkan</option>
                            <option value="browse">Jelajahi</option>
              </select>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#NavigationTreeDefaultTabTable" title="Kembalikan nilai bawaan" style="display: inline-block; opacity: 0.25;"><img src="./db_inventori_fitrah_files/dot.gif" title="Kembalikan nilai bawaan" alt="Kembalikan nilai bawaan" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NavigationTreeDefaultTabTable2">Target buat ikon akses cepat kedua</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeDefaultTabTable2" target="documentation"><img src="./db_inventori_fitrah_files/dot.gif" title="Dokumentasi" alt="Dokumentasi" class="icon ic_b_help"></a>
      </span>
    
    
      </th>

  <td>
          <select name="NavigationTreeDefaultTabTable2" id="NavigationTreeDefaultTabTable2" class="w-75">
                            <option value="" selected=""></option>
                            <option value="structure">Struktur</option>
                            <option value="sql">SQL</option>
                            <option value="search">Cari</option>
                            <option value="insert">Tambahkan</option>
                            <option value="browse">Jelajahi</option>
              </select>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#NavigationTreeDefaultTabTable2" title="Kembalikan nilai bawaan" style="display: inline-block; opacity: 0.25;"><img src="./db_inventori_fitrah_files/dot.gif" title="Kembalikan nilai bawaan" alt="Kembalikan nilai bawaan" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NavigationTreeTableSeparator">Pemisah hierarki tabel</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeTableSeparator" target="documentation"><img src="./db_inventori_fitrah_files/dot.gif" title="Dokumentasi" alt="Dokumentasi" class="icon ic_b_help"></a>
      </span>
    
    
          <small>String yang memisahkan tabel ke dalam tingkat hierarki yang berbeda.</small>
      </th>

  <td>
                <input type="text" size="25" name="NavigationTreeTableSeparator" id="NavigationTreeTableSeparator" value="__" class="">
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#NavigationTreeTableSeparator" title="Kembalikan nilai bawaan" style="display: inline-block; opacity: 0.25;"><img src="./db_inventori_fitrah_files/dot.gif" title="Kembalikan nilai bawaan" alt="Kembalikan nilai bawaan" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NavigationTreeTableLevel">Kedalaman hierarki tabel maksimum</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeTableLevel" target="documentation"><img src="./db_inventori_fitrah_files/dot.gif" title="Dokumentasi" alt="Dokumentasi" class="icon ic_b_help"></a>
      </span>
    
    
      </th>

  <td>
          <input type="number" name="NavigationTreeTableLevel" id="NavigationTreeTableLevel" value="1" class="">
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db_inventori_fitrah#NavigationTreeTableLevel" title="Kembalikan nilai bawaan" style="display: inline-block; opacity: 0.25;"><img src="./db_inventori_fitrah_files/dot.gif" title="Kembalikan nilai bawaan" alt="Kembalikan nilai bawaan" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>

              </tbody></table>
            </fieldset>
          </div>

                  </div>
      </div>
      </div>
</form>

<script type="text/javascript">
  if (typeof configInlineParams === 'undefined' || !Array.isArray(configInlineParams)) {
    configInlineParams = [];
  }
  configInlineParams.push(function () {
    registerFieldValidator('FirstLevelNavigationItems', 'validatePositiveNumber', true);
registerFieldValidator('NavigationTreeDisplayItemFilterMinimum', 'validatePositiveNumber', true);
registerFieldValidator('NumRecentTables', 'validateNonNegativeNumber', true);
registerFieldValidator('NumFavoriteTables', 'validateNonNegativeNumber', true);
registerFieldValidator('NavigationWidth', 'validateNonNegativeNumber', true);
registerFieldValidator('MaxNavigationItems', 'validatePositiveNumber', true);
registerFieldValidator('NavigationTreeTableLevel', 'validatePositiveNumber', true);

    $.extend(Messages, {
      'error_nan_p': 'Bukan\u0020angka\u0020positif\u0021',
      'error_nan_nneg': 'Bukan\u0020angka\u0020non\u002Dnegatif\u0021',
      'error_incorrect_port': 'Bukan\u0020angka\u0020port\u0020yang\u0020sah\u0021',
      'error_invalid_value': 'Nilai\u0020yang\u0020salah\u0021',
      'error_value_lte': 'Nilai\u0020harus\u0020sama\u0020dengan\u0020atau\u0020lebih\u0020kecil\u0020dari\u0020\u0025s\u0021',
    });

    $.extend(defaultValues, {
      'ShowDatabasesNavigationAsTree': true,
      'NavigationLinkWithMainPanel': true,
      'NavigationDisplayLogo': true,
      'NavigationLogoLink': 'index.php',
      'NavigationLogoLinkWindow': ['main'],
      'NavigationTreePointerEnable': true,
      'FirstLevelNavigationItems': '100',
      'NavigationTreeDisplayItemFilterMinimum': '30',
      'NumRecentTables': '10',
      'NumFavoriteTables': '10',
      'NavigationWidth': '240',
      'MaxNavigationItems': '50',
      'NavigationTreeEnableGrouping': true,
      'NavigationTreeEnableExpansion': true,
      'NavigationTreeShowTables': true,
      'NavigationTreeShowViews': true,
      'NavigationTreeShowFunctions': true,
      'NavigationTreeShowProcedures': true,
      'NavigationTreeShowEvents': true,
      'NavigationTreeAutoexpandSingleDb': true,
      'NavigationDisplayServers': true,
      'DisplayServersList': false,
      'NavigationTreeDisplayDbFilterMinimum': '30',
      'NavigationTreeDbSeparator': '_',
      'NavigationTreeDefaultTabTable': ['structure'],
      'NavigationTreeDefaultTabTable2': [''],
      'NavigationTreeTableSeparator': '__',
      'NavigationTreeTableLevel': '1'
    });
  });
  if (typeof configScriptLoaded !== 'undefined' && configInlineParams) {
    loadInlineConfig();
  }
</script>
</div></div><div class="ui-dialog-buttonpane ui-widget-content ui-helper-clearfix"><div class="ui-dialog-buttonset"><button type="button" class="btn btn-primary">Terapkan</button><button type="button" class="btn btn-secondary">Batal</button></div></div><div class="ui-resizable-handle ui-resizable-n" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-e" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-s" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-w" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-se ui-icon ui-icon-gripsmall-diagonal-se" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-sw" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-ne" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-nw" style="z-index: 90;"></div></div></body></html>