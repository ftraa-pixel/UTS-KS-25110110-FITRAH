package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Koneksi {

    public static Connection getConnection()
            throws SQLException {

        String url
                = "jdbc:mysql://127.0.0.1:3306/db_inventori_fitrah";

        String user = "root";
        String password = "";

        Connection conn = DriverManager.getConnection(
                url, user, password
        );

        System.out.println("Koneksi database berhasil!");

        return conn;
    }
}
