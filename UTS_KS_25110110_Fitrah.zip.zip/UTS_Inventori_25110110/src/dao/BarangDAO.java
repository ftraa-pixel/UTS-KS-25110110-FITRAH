package dao;

import model.Barang;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class BarangDAO {

    // Menyimpan data
    public boolean simpan(Barang b) {

        String sql = "INSERT INTO barang VALUES (?, ?, ?, ?)";

        try (Connection con = Koneksi.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, b.getKodeBarang());
            ps.setString(2, b.getNamaBarang());
            ps.setString(3, b.getKategori());
            ps.setInt(4, b.getStok());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println("Gagal menyimpan: " + e.getMessage());
            return false;
        }
    }

    // Mengambil semua data
    public List<Barang> tampilSemua() {

        List<Barang> daftar = new ArrayList<>();

        String sql = "SELECT * FROM barang";

        try (Connection con = Koneksi.getConnection()) {

            if (con == null) {
                throw new SQLException(
                        "Koneksi database bernilai NULL!"
                );
            }

            try (PreparedStatement ps
                    = con.prepareStatement(sql);
                    ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {

                    Barang b = new Barang(
                            rs.getString("kode_barang"),
                            rs.getString("nama_barang"),
                            rs.getString("kategori"),
                            rs.getInt("stok")
                    );

                    daftar.add(b);
                }
            }

        } catch (SQLException e) {

            System.out.println(
                    "Gagal mengambil data: " + e.getMessage()
            );

            JOptionPane.showMessageDialog(
                    null,
                    "Gagal mengambil data: " + e.getMessage()
            );
        }

        return daftar;
    }

    // MENGUBAH DATA BARANG
    public boolean ubah(Barang b) {

        String sql = "UPDATE barang SET "
                + "nama_barang=?, kategori=?, stok=? "
                + "WHERE kode_barang=?";

        try (Connection con = Koneksi.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, b.getNamaBarang());
            ps.setString(2, b.getKategori());
            ps.setInt(3, b.getStok());
            ps.setString(4, b.getKodeBarang());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {

            System.out.println("Gagal mengubah data: " + e.getMessage());
            return false;
        }
    }

    // MENGHAPUS DATA BARANG
    public boolean hapus(String kode) {

        String sql = "DELETE FROM barang WHERE kode_barang=?";

        try (Connection con = Koneksi.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, kode);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {

            System.out.println("Gagal menghapus data: " + e.getMessage());
            return false;
        }
    }

}
