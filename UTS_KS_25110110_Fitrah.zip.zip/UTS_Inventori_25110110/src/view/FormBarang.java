package view;

import dao.BarangDAO;
import model.Barang;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class FormBarang extends JFrame {

    private JTextField txtKode;
    private JTextField txtNama;
    private JTextField txtStok;

    private JComboBox<String> cmbKategori;

    private JButton btnSimpan;
    private JButton btnUbah;
    private JButton btnHapus;
    private JButton btnBersihkan;

    private JTable tabel;
    private DefaultTableModel modelTabel;

    private BarangDAO dao = new BarangDAO();

    public FormBarang() {

        setTitle("Aplikasi Inventori Barang Laboratorium");
        setSize(750, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Panel utama
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        );

        // Judul
        JLabel judul = new JLabel(
            "DATA BARANG LABORATORIUM",
            JLabel.CENTER
        );

        judul.setFont(new Font("Arial", Font.BOLD, 20));

        panel.add(judul, BorderLayout.NORTH);

        // Panel input
        JPanel input = new JPanel(new GridLayout(4, 2, 10, 10));

        txtKode = new JTextField();
        txtNama = new JTextField();
        txtStok = new JTextField();

        cmbKategori = new JComboBox<>(
            new String[]{
                "Komputer",
                "Jaringan",
                "Alat Ukur"
            }
        );

        input.add(new JLabel("Kode Barang"));
        input.add(txtKode);

        input.add(new JLabel("Nama Barang"));
        input.add(txtNama);

        input.add(new JLabel("Kategori"));
        input.add(cmbKategori);

        input.add(new JLabel("Stok"));
        input.add(txtStok);

        // Tombol
        btnSimpan = new JButton("Simpan");
        btnUbah = new JButton("Ubah");
        btnHapus = new JButton("Hapus");
        btnBersihkan = new JButton("Bersihkan");

        JPanel tombol = new JPanel();

        tombol.add(btnSimpan);
        tombol.add(btnUbah);
        tombol.add(btnHapus);
        tombol.add(btnBersihkan);

        // Panel bagian atas
        JPanel atas = new JPanel(new BorderLayout(10, 10));

        atas.add(input, BorderLayout.CENTER);
        atas.add(tombol, BorderLayout.SOUTH);

        panel.add(atas, BorderLayout.CENTER);

        // Tabel
        modelTabel = new DefaultTableModel(
            new String[]{
                "Kode Barang",
                "Nama Barang",
                "Kategori",
                "Stok"
            }, 0
        );

        tabel = new JTable(modelTabel);

        JScrollPane scroll = new JScrollPane(tabel);

        panel.add(scroll, BorderLayout.SOUTH);

        setContentPane(panel);

        // Event tombol simpan
        btnSimpan.addActionListener(e -> simpanData());

        // Event tombol ubah
        btnUbah.addActionListener(e -> ubahData());

        // Event tombol hapus
        btnHapus.addActionListener(e -> hapusData());

        // Event tombol bersihkan
        btnBersihkan.addActionListener(e -> bersihkan());

        // Event klik tabel
        tabel.getSelectionModel().addListSelectionListener(e -> {

            if (!e.getValueIsAdjusting()) {

                int baris = tabel.getSelectedRow();

                if (baris >= 0) {

                    txtKode.setText(
                        modelTabel.getValueAt(baris, 0).toString()
                    );

                    txtNama.setText(
                        modelTabel.getValueAt(baris, 1).toString()
                    );

                    cmbKategori.setSelectedItem(
                        modelTabel.getValueAt(baris, 2).toString()
                    );

                    txtStok.setText(
                        modelTabel.getValueAt(baris, 3).toString()
                    );
                }
            }
        });

        tampilData();
    }

    // Proses simpan
    private void simpanData() {

        try {

            String kode = txtKode.getText().trim();
            String nama = txtNama.getText().trim();
            String kategori = cmbKategori.getSelectedItem().toString();
            String stokText = txtStok.getText().trim();

            if (kode.isEmpty() || nama.isEmpty() || stokText.isEmpty()) {

                JOptionPane.showMessageDialog(
                    this,
                    "Semua data harus diisi!"
                );

                return;
            }

            int stok = Integer.parseInt(stokText);

            if (stok <= 0) {

                JOptionPane.showMessageDialog(
                    this,
                    "Stok harus lebih dari 0!"
                );

                return;
            }

            Barang b = new Barang(
                kode, nama, kategori, stok
            );

            if (dao.simpan(b)) {

                JOptionPane.showMessageDialog(
                    this,
                    "Data berhasil disimpan!"
                );

                tampilData();
                bersihkan();

            } else {

                JOptionPane.showMessageDialog(
                    this,
                    "Data gagal disimpan!"
                );
            }

        } catch (NumberFormatException e) {

            JOptionPane.showMessageDialog(
                this,
                "Stok harus berupa angka!"
            );
        }
    }

    // Proses ubah
    private void ubahData() {

        try {

            String kode = txtKode.getText().trim();
            String nama = txtNama.getText().trim();
            String kategori = cmbKategori.getSelectedItem().toString();
            String stokText = txtStok.getText().trim();

            if (kode.isEmpty() || nama.isEmpty() || stokText.isEmpty()) {

                JOptionPane.showMessageDialog(
                    this,
                    "Pilih data dan lengkapi semua kolom!"
                );

                return;
            }

            int stok = Integer.parseInt(stokText);

            if (stok <= 0) {
                JOptionPane.showMessageDialog(
                    this,
                    "Stok harus lebih dari 0!"
                );
                return;
            }

            Barang b = new Barang(
                kode, nama, kategori, stok
            );

            if (dao.ubah(b)) {

                JOptionPane.showMessageDialog(
                    this,
                    "Data berhasil diubah!"
                );

                tampilData();
                bersihkan();

            } else {

                JOptionPane.showMessageDialog(
                    this,
                    "Data gagal diubah atau kode tidak ditemukan!"
                );
            }

        } catch (NumberFormatException e) {

            JOptionPane.showMessageDialog(
                this,
                "Stok harus berupa angka!"
            );
        }
    }

    // Proses hapus
   
private void hapusData() {

    String kode = txtKode.getText().trim();

    if (kode.isEmpty()) {
        JOptionPane.showMessageDialog(
            this,
            "Pilih data yang ingin dihapus!"
        );
        return;
    }

    int konfirmasi = JOptionPane.showConfirmDialog(
        this,
        "Apakah Anda yakin ingin menghapus data " + kode + "?",
        "Konfirmasi Hapus",
        JOptionPane.YES_NO_OPTION
    );

    if (konfirmasi == JOptionPane.YES_OPTION) {

        if (dao.hapus(kode)) {

            JOptionPane.showMessageDialog(
                this,
                "Data berhasil dihapus!"
            );

            tampilData();
            bersihkan();

        } else {

            JOptionPane.showMessageDialog(
                this,
                "Data tidak ditemukan atau gagal dihapus!"
            );
        }
    }
}



    // Menampilkan data ke tabel
    private void tampilData() {

        modelTabel.setRowCount(0);

        List<Barang> daftar = dao.tampilSemua();

        for (Barang b : daftar) {

            modelTabel.addRow(new Object[]{
                b.getKodeBarang(),
                b.getNamaBarang(),
                b.getKategori(),
                b.getStok()
            });
        }
    }

    // Membersihkan form
    private void bersihkan() {

        txtKode.setText("");
        txtNama.setText("");
        txtStok.setText("");

        cmbKategori.setSelectedIndex(0);

        tabel.clearSelection();

        txtKode.requestFocus();
    }

    // Main program
    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            new FormBarang().setVisible(true);

        });
    }
}